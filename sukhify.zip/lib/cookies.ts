import { serialize, parse } from "cookie"

// Set a secure cookie
export function setSecureCookie(name: string, value: string, options: any = {}) {
  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV !== "development",
    sameSite: "strict",
    maxAge: 7 * 24 * 60 * 60, // 1 week
    path: "/",
    ...options,
  }

  document.cookie = serialize(name, value, cookieOptions)
}

// Get a cookie value
export function getCookie(name: string) {
  const cookies = parse(document.cookie)
  return cookies[name]
}

// Remove a cookie
export function removeCookie(name: string) {
  document.cookie = serialize(name, "", {
    maxAge: -1,
    path: "/",
  })
}

