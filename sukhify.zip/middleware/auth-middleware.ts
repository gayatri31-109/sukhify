import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"

// This middleware will run on all routes except the ones specified in the matcher
export function middleware(request: NextRequest) {
  // Get the token from the cookies
  const token = request.cookies.get("sukhify-auth-token")?.value

  // Check if the path is the login page
  const isLoginPage = request.nextUrl.pathname === "/login"

  // If there's no token and the user is not on the login page, redirect to login
  if (!token && !isLoginPage) {
    const url = new URL("/login", request.url)
    return NextResponse.redirect(url)
  }

  // If there's a token, verify it
  if (token) {
    const { valid } = verifyToken(token)

    // If the token is invalid and the user is not on the login page, redirect to login
    if (!valid && !isLoginPage) {
      const url = new URL("/login", request.url)
      return NextResponse.redirect(url)
    }

    // If the token is valid and the user is on the login page, redirect to home
    if (valid && isLoginPage) {
      const url = new URL("/", request.url)
      return NextResponse.redirect(url)
    }
  }

  // Continue with the request
  return NextResponse.next()
}

// Configure the middleware to run on specific paths
export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * 1. /api routes
     * 2. /_next (Next.js internals)
     * 3. /fonts, /images (static files)
     * 4. /favicon.ico, /robots.txt (static files)
     */
    "/((?!api|_next|fonts|images|favicon.ico|robots.txt).*)",
  ],
}

