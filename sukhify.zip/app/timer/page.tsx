"use client"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Play, Pause, RotateCcw, Volume2, VolumeX, Settings, Bell, Coffee, Brain } from "lucide-react"

// Define timer presets
const timerPresets = [
  { name: "Pomodoro", work: 25, break: 5, longBreak: 15, cycles: 4 },
  { name: "Short Focus", work: 15, break: 3, longBreak: 10, cycles: 4 },
  { name: "Long Focus", work: 50, break: 10, longBreak: 30, cycles: 2 },
  { name: "Custom", work: 30, break: 5, longBreak: 15, cycles: 4 },
]

export default function BreakTimer() {
  const [activeTab, setActiveTab] = useState("timer")
  const [timerMode, setTimerMode] = useState<"work" | "break" | "longBreak">("work")
  const [isRunning, setIsRunning] = useState(false)
  const [timeLeft, setTimeLeft] = useState(25 * 60) // Default: 25 minutes in seconds
  const [selectedPreset, setSelectedPreset] = useState("Pomodoro")
  const [currentCycle, setCurrentCycle] = useState(1)
  const [totalCycles, setTotalCycles] = useState(4)
  const [showNotifications, setShowNotifications] = useState(true)
  const [playSound, setPlaySound] = useState(true)
  const [volume, setVolume] = useState(70)
  const [isMuted, setIsMuted] = useState(false)

  // Custom timer settings
  const [customSettings, setCustomSettings] = useState({
    work: 25,
    break: 5,
    longBreak: 15,
    cycles: 4,
  })

  // Audio reference
  const alarmSound = useRef<HTMLAudioElement | null>(null)

  // Initialize audio on component mount
  useEffect(() => {
    if (typeof window !== "undefined") {
      alarmSound.current = new Audio("/placeholder.svg") // This would be a real audio file in production
    }
  }, [])

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prevTime) => prevTime - 1)
      }, 1000)
    } else if (isRunning && timeLeft === 0) {
      handleTimerComplete()
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRunning, timeLeft])

  // Handle timer completion
  const handleTimerComplete = () => {
    setIsRunning(false)

    // Play sound if enabled
    if (playSound && !isMuted && alarmSound.current) {
      alarmSound.current.volume = volume / 100
      alarmSound.current.play().catch((e) => console.error("Error playing sound:", e))
    }

    // Show notification if enabled
    if (showNotifications) {
      if (Notification.permission === "granted") {
        new Notification("Sukhify Timer", {
          body: `${timerMode === "work" ? "Work session" : "Break"} completed!`,
          icon: "/placeholder.svg?height=64&width=64",
        })
      } else if (Notification.permission !== "denied") {
        Notification.requestPermission()
      }
    }

    // Determine next timer mode
    if (timerMode === "work") {
      // After work session, check if we need a long break
      if (currentCycle % 4 === 0) {
        setTimerMode("longBreak")
        const preset = timerPresets.find((p) => p.name === selectedPreset) || timerPresets[0]
        setTimeLeft(preset.longBreak * 60)
      } else {
        setTimerMode("break")
        const preset = timerPresets.find((p) => p.name === selectedPreset) || timerPresets[0]
        setTimeLeft(preset.break * 60)
      }
    } else {
      // After break, start next work session
      setTimerMode("work")
      const preset = timerPresets.find((p) => p.name === selectedPreset) || timerPresets[0]
      setTimeLeft(preset.work * 60)

      // If coming from a break, increment cycle
      if (timerMode === "break" || timerMode === "longBreak") {
        setCurrentCycle((prev) => {
          const nextCycle = prev + 1
          // Reset cycles if we've completed all of them
          return nextCycle > totalCycles ? 1 : nextCycle
        })
      }
    }

    // Auto-start next session
    setIsRunning(true)
  }

  // Format time for display
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // Handle play/pause
  const toggleTimer = () => {
    setIsRunning(!isRunning)
  }

  // Handle reset
  const resetTimer = () => {
    setIsRunning(false)
    const preset = timerPresets.find((p) => p.name === selectedPreset) || timerPresets[0]
    setTimeLeft(preset.work * 60)
    setTimerMode("work")
    setCurrentCycle(1)
  }

  // Handle preset change
  const handlePresetChange = (preset: string) => {
    setSelectedPreset(preset)
    setIsRunning(false)

    const selectedPresetData = timerPresets.find((p) => p.name === preset)
    if (selectedPresetData) {
      setTimeLeft(selectedPresetData.work * 60)
      setTotalCycles(selectedPresetData.cycles)
      setTimerMode("work")
      setCurrentCycle(1)
    }
  }

  // Handle volume change
  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0])
    if (value[0] === 0) {
      setIsMuted(true)
    } else if (isMuted) {
      setIsMuted(false)
    }
  }

  // Handle mute toggle
  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  // Calculate progress percentage
  const getProgressPercentage = () => {
    const preset = timerPresets.find((p) => p.name === selectedPreset) || timerPresets[0]
    const totalTime =
      timerMode === "work" ? preset.work * 60 : timerMode === "break" ? preset.break * 60 : preset.longBreak * 60

    return ((totalTime - timeLeft) / totalTime) * 100
  }

  // Update custom settings
  const updateCustomSetting = (setting: keyof typeof customSettings, value: number) => {
    setCustomSettings((prev) => ({
      ...prev,
      [setting]: value,
    }))

    // If custom preset is selected, update the timer
    if (selectedPreset === "Custom") {
      setIsRunning(false)
      if (setting === "work" && timerMode === "work") {
        setTimeLeft(value * 60)
      } else if (setting === "break" && timerMode === "break") {
        setTimeLeft(value * 60)
      } else if (setting === "longBreak" && timerMode === "longBreak") {
        setTimeLeft(value * 60)
      } else if (setting === "cycles") {
        setTotalCycles(value)
      }
    }
  }

  return (
    <div className="container mx-auto px-4 py-32">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-4xl mx-auto"
      >
        <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
          Break Timer
        </h1>
        <p className="text-lg text-gray-700 dark:text-gray-300 mb-10 text-center">
          Use the Pomodoro technique to balance focused work with regular breaks for optimal mental health.
        </p>

        <Tabs defaultValue="timer" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="timer" className="flex items-center gap-2">
              <Coffee className="h-4 w-4" /> Timer
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" /> Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="timer">
            <Card className="border-none shadow-lg">
              <CardHeader className="pb-4">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-2xl">
                      {timerMode === "work" ? "Focus Time" : timerMode === "break" ? "Short Break" : "Long Break"}
                    </CardTitle>
                    <CardDescription>
                      Cycle {currentCycle} of {totalCycles}
                    </CardDescription>
                  </div>

                  <Select value={selectedPreset} onValueChange={handlePresetChange}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Select preset" />
                    </SelectTrigger>
                    <SelectContent>
                      {timerPresets.map((preset) => (
                        <SelectItem key={preset.name} value={preset.name}>
                          {preset.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>

              <CardContent className="flex flex-col items-center">
                <div className="relative w-64 h-64 mb-8">
                  {/* Progress circle */}
                  <svg className="w-full h-full" viewBox="0 0 100 100">
                    {/* Background circle */}
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke={timerMode === "work" ? "#e0e7ff" : timerMode === "break" ? "#dcfce7" : "#f3e8ff"}
                      strokeWidth="8"
                      className="dark:opacity-20"
                    />

                    {/* Progress circle */}
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke={
                        timerMode === "work"
                          ? "url(#gradient-work)"
                          : timerMode === "break"
                            ? "url(#gradient-break)"
                            : "url(#gradient-longbreak)"
                      }
                      strokeWidth="8"
                      strokeDasharray="282.7"
                      strokeDashoffset={282.7 - (282.7 * getProgressPercentage()) / 100}
                      strokeLinecap="round"
                      transform="rotate(-90 50 50)"
                    />

                    {/* Gradients */}
                    <defs>
                      <linearGradient id="gradient-work" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#8b5cf6" />
                        <stop offset="100%" stopColor="#6366f1" />
                      </linearGradient>
                      <linearGradient id="gradient-break" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#10b981" />
                        <stop offset="100%" stopColor="#34d399" />
                      </linearGradient>
                      <linearGradient id="gradient-longbreak" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#a855f7" />
                        <stop offset="100%" stopColor="#d946ef" />
                      </linearGradient>
                    </defs>
                  </svg>

                  {/* Timer display */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-5xl font-bold">{formatTime(timeLeft)}</div>
                  </div>
                </div>

                <div className="flex items-center space-x-4 mb-8">
                  <Button variant="outline" size="icon" onClick={resetTimer} className="h-12 w-12 rounded-full">
                    <RotateCcw className="h-5 w-5" />
                  </Button>

                  <Button
                    size="icon"
                    onClick={toggleTimer}
                    className="h-16 w-16 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                  >
                    {isRunning ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-1" />}
                  </Button>

                  <Button variant="outline" size="icon" onClick={toggleMute} className="h-12 w-12 rounded-full">
                    {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                  </Button>
                </div>

                <div className="w-full max-w-md grid grid-cols-3 gap-4 mb-6">
                  <Button
                    variant={timerMode === "work" ? "default" : "outline"}
                    className={timerMode === "work" ? "bg-gradient-to-r from-purple-600 to-indigo-600" : ""}
                    onClick={() => {
                      setTimerMode("work")
                      setIsRunning(false)
                      const preset = timerPresets.find((p) => p.name === selectedPreset) || timerPresets[0]
                      setTimeLeft(preset.work * 60)
                    }}
                  >
                    Focus
                  </Button>

                  <Button
                    variant={timerMode === "break" ? "default" : "outline"}
                    className={timerMode === "break" ? "bg-gradient-to-r from-green-600 to-teal-600" : ""}
                    onClick={() => {
                      setTimerMode("break")
                      setIsRunning(false)
                      const preset = timerPresets.find((p) => p.name === selectedPreset) || timerPresets[0]
                      setTimeLeft(preset.break * 60)
                    }}
                  >
                    Short Break
                  </Button>

                  <Button
                    variant={timerMode === "longBreak" ? "default" : "outline"}
                    className={timerMode === "longBreak" ? "bg-gradient-to-r from-purple-600 to-pink-600" : ""}
                    onClick={() => {
                      setTimerMode("longBreak")
                      setIsRunning(false)
                      const preset = timerPresets.find((p) => p.name === selectedPreset) || timerPresets[0]
                      setTimeLeft(preset.longBreak * 60)
                    }}
                  >
                    Long Break
                  </Button>
                </div>
              </CardContent>

              <CardFooter className="flex flex-col space-y-4">
                <div className="w-full p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <h3 className="text-sm font-medium mb-2 flex items-center">
                    <Brain className="h-4 w-4 mr-2 text-purple-600" /> Mental Health Tip
                  </h3>
                  <p className="text-sm text-gray-700 dark:text-gray-300">
                    Taking regular breaks improves focus, reduces stress, and prevents burnout. Use your break time to
                    stretch, hydrate, or practice deep breathing.
                  </p>
                </div>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Timer Settings</CardTitle>
                <CardDescription>Customize your timer preferences and notifications</CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Time Intervals (minutes)</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="work-time">Focus Duration</Label>
                          <span>{customSettings.work} min</span>
                        </div>
                        <Slider
                          id="work-time"
                          min={5}
                          max={60}
                          step={5}
                          value={[customSettings.work]}
                          onValueChange={(value) => updateCustomSetting("work", value[0])}
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="break-time">Short Break Duration</Label>
                          <span>{customSettings.break} min</span>
                        </div>
                        <Slider
                          id="break-time"
                          min={1}
                          max={15}
                          step={1}
                          value={[customSettings.break]}
                          onValueChange={(value) => updateCustomSetting("break", value[0])}
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="long-break-time">Long Break Duration</Label>
                          <span>{customSettings.longBreak} min</span>
                        </div>
                        <Slider
                          id="long-break-time"
                          min={5}
                          max={30}
                          step={5}
                          value={[customSettings.longBreak]}
                          onValueChange={(value) => updateCustomSetting("longBreak", value[0])}
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="cycles">Cycles Before Long Break</Label>
                          <span>{customSettings.cycles}</span>
                        </div>
                        <Slider
                          id="cycles"
                          min={1}
                          max={6}
                          step={1}
                          value={[customSettings.cycles]}
                          onValueChange={(value) => updateCustomSetting("cycles", value[0])}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Notifications</h3>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="notifications">Desktop Notifications</Label>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Receive notifications when timer completes
                      </p>
                    </div>
                    <Switch id="notifications" checked={showNotifications} onCheckedChange={setShowNotifications} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="sound">Sound Alerts</Label>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Play sound when timer completes</p>
                    </div>
                    <Switch id="sound" checked={playSound} onCheckedChange={setPlaySound} />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="volume">Alert Volume</Label>
                      <div className="flex items-center">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={toggleMute}
                          className="h-8 w-8 mr-2"
                          disabled={!playSound}
                        >
                          {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                        </Button>
                        <span>{isMuted ? 0 : volume}%</span>
                      </div>
                    </div>
                    <Slider
                      id="volume"
                      min={0}
                      max={100}
                      step={5}
                      value={[isMuted ? 0 : volume]}
                      onValueChange={handleVolumeChange}
                      disabled={!playSound}
                    />
                  </div>
                </div>
              </CardContent>

              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setActiveTab("timer")}>
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    // Save settings and apply them
                    if (selectedPreset === "Custom") {
                      // Update timer with custom settings
                      if (timerMode === "work") {
                        setTimeLeft(customSettings.work * 60)
                      } else if (timerMode === "break") {
                        setTimeLeft(customSettings.break * 60)
                      } else {
                        setTimeLeft(customSettings.longBreak * 60)
                      }
                      setTotalCycles(customSettings.cycles)
                    }
                    setActiveTab("timer")
                  }}
                  className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                >
                  Save Settings
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-12 text-center">
          <h2 className="text-2xl font-bold mb-4">Why Take Regular Breaks?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Brain className="h-5 w-5 mr-2 text-purple-600" /> Cognitive Benefits
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 dark:text-gray-300">
                  Regular breaks help maintain attention, improve problem-solving abilities, and enhance creativity by
                  giving your brain time to process information.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Coffee className="h-5 w-5 mr-2 text-amber-600" /> Stress Reduction
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 dark:text-gray-300">
                  Taking breaks reduces mental fatigue, lowers stress hormones, and prevents burnout by giving your mind
                  and body time to recover from focused work.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Bell className="h-5 w-5 mr-2 text-red-600" /> Physical Health
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 dark:text-gray-300">
                  Breaks allow you to move, stretch, and rest your eyes, reducing the physical strain of prolonged
                  sitting and screen time.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

