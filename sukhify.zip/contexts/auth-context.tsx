"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import {
  findUserByUsername,
  verifyPassword,
  generateToken,
  verifyToken,
  isUserLockedOut,
  recordFailedAttempt,
  resetLoginAttempts,
  generateVerificationCode,
  sendVerificationCode,
  verifyTwoFactorCode,
  registerUser,
} from "@/lib/auth"
import { setSecureCookie, getCookie, removeCookie } from "@/lib/cookies"

interface AuthContextType {
  isAuthenticated: boolean
  isLoading: boolean
  user: { id: string; username: string; role: string } | null
  error: string | null
  twoFactorRequired: boolean
  login: (username: string, password: string) => Promise<boolean>
  register: (username: string, email: string, password: string) => Promise<{ success: boolean; message?: string }>
  verifyTwoFactor: (code: string) => Promise<boolean>
  logout: () => void
  resendVerificationCode: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<{ id: string; username: string; role: string } | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [twoFactorRequired, setTwoFactorRequired] = useState(false)
  const [pendingUser, setPendingUser] = useState<any>(null)
  const [verificationCode, setVerificationCode] = useState<string | null>(null)

  useEffect(() => {
    // Check if user is already authenticated
    const token = getCookie("sukhify-auth-token")

    if (token) {
      const { valid, payload } = verifyToken(token)

      if (valid && payload) {
        setIsAuthenticated(true)
        setUser({
          id: payload.sub,
          username: payload.username,
          role: payload.role,
        })
      } else {
        // Token is invalid or expired
        removeCookie("sukhify-auth-token")
      }
    }

    setIsLoading(false)
  }, [])

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      setError(null)

      // Check if user is locked out
      if (isUserLockedOut(username)) {
        setError("Account is temporarily locked due to too many failed attempts. Please try again later.")
        return false
      }

      // Find user
      const user = findUserByUsername(username)

      if (!user) {
        setError("Invalid username or password")
        recordFailedAttempt(username)
        return false
      }

      // Verify password
      const isValid = await verifyPassword(password, user.passwordHash)

      if (!isValid) {
        setError("Invalid username or password")
        recordFailedAttempt(username)
        return false
      }

      // Reset login attempts
      resetLoginAttempts(username)

      // Generate verification code for 2FA
      const code = generateVerificationCode()
      setVerificationCode(code)

      // In a real app, this would send the code via SMS or email
      await sendVerificationCode(user.email, code)

      // Store user info for after 2FA verification
      setPendingUser({
        id: user.id,
        username: user.username,
        role: user.role,
      })

      // Require 2FA
      setTwoFactorRequired(true)

      return true
    } catch (error) {
      setError("An error occurred during login")
      return false
    }
  }

  const register = async (
    username: string,
    email: string,
    password: string,
  ): Promise<{ success: boolean; message?: string }> => {
    try {
      setError(null)

      // Validate inputs
      if (!username || !email || !password) {
        setError("All fields are required")
        return { success: false, message: "All fields are required" }
      }

      if (username.length < 3) {
        setError("Username must be at least 3 characters")
        return { success: false, message: "Username must be at least 3 characters" }
      }

      if (password.length < 8) {
        setError("Password must be at least 8 characters")
        return { success: false, message: "Password must be at least 8 characters" }
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(email)) {
        setError("Please enter a valid email address")
        return { success: false, message: "Please enter a valid email address" }
      }

      // Register the user
      const result = await registerUser(username, email, password)

      if (!result.success) {
        setError(result.message || "Registration failed")
        return { success: false, message: result.message }
      }

      return { success: true }
    } catch (error) {
      setError("An error occurred during registration")
      return { success: false, message: "An error occurred during registration" }
    }
  }

  const verifyTwoFactor = async (code: string): Promise<boolean> => {
    try {
      if (!verificationCode || !pendingUser) {
        setError("Authentication error. Please try logging in again.")
        return false
      }

      // Verify the code
      const isValid = verifyTwoFactorCode(code, verificationCode)

      if (!isValid) {
        setError("Invalid verification code")
        return false
      }

      // Generate JWT token
      const token = generateToken(pendingUser.id, pendingUser.username, pendingUser.role)

      // Store token in secure cookie
      setSecureCookie("sukhify-auth-token", token)

      // Set authenticated state
      setIsAuthenticated(true)
      setUser(pendingUser)
      setTwoFactorRequired(false)
      setPendingUser(null)
      setVerificationCode(null)

      return true
    } catch (error) {
      setError("An error occurred during verification")
      return false
    }
  }

  const resendVerificationCode = async (): Promise<void> => {
    if (!pendingUser) {
      setError("Authentication error. Please try logging in again.")
      return
    }

    // Generate new verification code
    const code = generateVerificationCode()
    setVerificationCode(code)

    // Find user to get email
    const user = findUserByUsername(pendingUser.username)

    if (user) {
      // In a real app, this would send the code via SMS or email
      await sendVerificationCode(user.email, code)
    }
  }

  const logout = () => {
    removeCookie("sukhify-auth-token")
    setIsAuthenticated(false)
    setUser(null)
    setTwoFactorRequired(false)
    setPendingUser(null)
    setVerificationCode(null)
  }

  // Don't render children until we've checked authentication status
  if (isLoading) {
    return null
  }

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isLoading,
        user,
        error,
        twoFactorRequired,
        login,
        register,
        verifyTwoFactor,
        logout,
        resendVerificationCode,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

