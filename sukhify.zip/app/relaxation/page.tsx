"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Play, Pause, SkipBack, Volume2, VolumeX, Clock, Sparkles, Wind, Music, Heart } from "lucide-react"
import Link from "next/link"
import ProtectedRoute from "@/components/protected-route"

const relaxationTechniques = [
  {
    id: "breathing",
    title: "Breathing Exercises",
    icon: <Wind className="h-6 w-6" />,
    techniques: [
      {
        name: "4-7-8 Breathing",
        description:
          "Inhale for 4 seconds, hold for 7 seconds, exhale for 8 seconds. This technique helps calm the nervous system.",
        steps: [
          "Find a comfortable seated position",
          "Place the tip of your tongue against the ridge behind your upper front teeth",
          "Exhale completely through your mouth, making a whoosh sound",
          "Close your mouth and inhale quietly through your nose for 4 seconds",
          "Hold your breath for 7 seconds",
          "Exhale completely through your mouth for 8 seconds, making a whoosh sound",
          "Repeat the cycle 3-4 times",
        ],
        benefits: ["Reduces anxiety", "Helps with insomnia", "Manages cravings", "Decreases stress"],
      },
      {
        name: "Box Breathing",
        description: "Equal duration for inhaling, holding, exhaling, and holding. Creates balance and calm.",
        steps: [
          "Sit upright in a comfortable position",
          "Slowly exhale completely",
          "Inhale slowly through your nose for 4 seconds",
          "Hold your breath for 4 seconds",
          "Exhale through your mouth for 4 seconds",
          "Hold your breath for 4 seconds before inhaling again",
          "Repeat for at least 5 minutes",
        ],
        benefits: [
          "Improves concentration",
          "Clears the mind",
          "Reduces stress",
          "Regulates the autonomic nervous system",
        ],
      },
      {
        name: "Diaphragmatic Breathing",
        description: "Deep belly breathing that engages the diaphragm fully for maximum oxygen exchange.",
        steps: [
          "Lie on your back with knees bent or sit in a comfortable position",
          "Place one hand on your chest and the other on your abdomen",
          "Breathe in slowly through your nose, feeling your abdomen rise",
          "Keep your chest relatively still",
          "Exhale slowly through pursed lips",
          "Repeat for 5-10 minutes",
        ],
        benefits: ["Reduces blood pressure", "Slows heart rate", "Relaxes muscles", "Improves core stability"],
      },
    ],
  },
  {
    id: "meditation",
    title: "Meditation Practices",
    icon: <Sparkles className="h-6 w-6" />,
    techniques: [
      {
        name: "Mindfulness Meditation",
        description:
          "Focusing on the present moment without judgment, observing thoughts and sensations as they arise.",
        steps: [
          "Find a quiet and comfortable place to sit",
          "Set a timer for your desired duration (start with 5-10 minutes)",
          "Close your eyes or maintain a soft gaze",
          "Focus on your natural breathing",
          "When your mind wanders, gently bring attention back to your breath",
          "Observe thoughts without judgment, letting them pass like clouds",
          "Gradually extend your practice time as you become more comfortable",
        ],
        benefits: ["Reduces rumination", "Improves focus", "Decreases emotional reactivity", "Enhances self-awareness"],
      },
      {
        name: "Body Scan Meditation",
        description:
          "Systematically focusing attention on different parts of the body, noticing sensations without trying to change them.",
        steps: [
          "Lie down in a comfortable position",
          "Close your eyes and take a few deep breaths",
          "Begin by bringing awareness to your feet",
          "Slowly move your attention upward through each part of your body",
          "Notice any sensations, tension, or comfort in each area",
          "If you notice tension, breathe into that area and allow it to relax",
          "Continue until you've scanned your entire body",
        ],
        benefits: [
          "Releases physical tension",
          "Improves body awareness",
          "Helps with insomnia",
          "Reduces chronic pain",
        ],
      },
      {
        name: "Loving-Kindness Meditation",
        description: "Cultivating feelings of goodwill, kindness, and warmth towards yourself and others.",
        steps: [
          "Sit comfortably with eyes closed",
          "Begin by directing loving phrases toward yourself: 'May I be happy, may I be healthy, may I be safe, may I live with ease'",
          "Visualize the warmth and love spreading through your body",
          "Next, direct these phrases toward a loved one",
          "Then toward a neutral person in your life",
          "Then toward someone difficult",
          "Finally, extend these wishes to all beings everywhere",
        ],
        benefits: [
          "Increases positive emotions",
          "Decreases illness symptoms",
          "Develops empathy",
          "Reduces self-criticism",
        ],
      },
    ],
  },
  {
    id: "physical",
    title: "Physical Relaxation",
    icon: <Heart className="h-6 w-6" />,
    techniques: [
      {
        name: "Progressive Muscle Relaxation",
        description:
          "Tensing and then releasing different muscle groups to create awareness of tension and relaxation.",
        steps: [
          "Find a quiet place and sit or lie down comfortably",
          "Take a few deep breaths",
          "Start with your feet: tense the muscles as tightly as you can for 5 seconds",
          "Release the tension and notice how your muscles feel when relaxed",
          "Move progressively upward through your body (calves, thighs, abdomen, etc.)",
          "Tense each muscle group for 5 seconds, then relax for 30 seconds",
          "Notice the difference between tension and relaxation",
        ],
        benefits: ["Reduces physical tension", "Decreases anxiety", "Improves sleep quality", "Relieves headaches"],
      },
      {
        name: "Gentle Yoga",
        description: "Combining gentle stretches with mindful breathing to release tension and promote relaxation.",
        steps: [
          "Find a quiet space with room to move",
          "Begin in a comfortable seated position",
          "Take a few deep breaths to center yourself",
          "Move through gentle poses like child's pose, cat-cow, and gentle twists",
          "Hold each pose for 3-5 breaths",
          "Focus on the sensation of stretching and breathing",
          "End with a few minutes in savasana (lying flat on your back)",
        ],
        benefits: ["Increases flexibility", "Reduces muscle tension", "Improves mind-body connection", "Enhances mood"],
      },
      {
        name: "Autogenic Training",
        description: "Using visual imagery and body awareness to reduce stress and induce relaxation.",
        steps: [
          "Sit or lie in a comfortable position",
          "Close your eyes and focus on your breathing",
          "Repeat phrases like 'My arms are heavy and warm' while focusing on the sensation",
          "Move through different body parts with similar phrases",
          "Include phrases about calm breathing and heartbeat",
          "End with phrases about a cool forehead and peaceful mind",
          "Practice for 10-15 minutes daily",
        ],
        benefits: ["Reduces stress hormones", "Lowers blood pressure", "Improves sleep", "Decreases anxiety symptoms"],
      },
    ],
  },
  {
    id: "sound",
    title: "Sound Therapy",
    icon: <Music className="h-6 w-6" />,
    techniques: [
      {
        name: "Nature Sounds",
        description: "Listening to recordings of natural environments to induce relaxation and reduce stress.",
        steps: [
          "Find a comfortable position in a quiet space",
          "Choose nature sounds that you find calming (rain, ocean waves, forest)",
          "Use headphones for an immersive experience",
          "Close your eyes and focus on the sounds",
          "Allow your mind to create imagery associated with the sounds",
          "Breathe deeply and let the sounds wash over you",
          "Practice for 10-20 minutes",
        ],
        benefits: ["Masks distracting noises", "Lowers stress hormones", "Improves focus", "Enhances mood"],
      },
      {
        name: "Guided Imagery",
        description: "Following verbal guidance to imagine peaceful scenes and experiences.",
        steps: [
          "Find a quiet, comfortable place to sit or lie down",
          "Choose a guided imagery recording that appeals to you",
          "Close your eyes and listen to the guidance",
          "Engage all your senses in the imagined scene",
          "Allow yourself to be fully present in the visualization",
          "Notice how your body feels as you relax into the imagery",
          "When finished, slowly return awareness to your surroundings",
        ],
        benefits: [
          "Reduces anxiety",
          "Decreases pain perception",
          "Improves sleep quality",
          "Enhances immune function",
        ],
      },
      {
        name: "Binaural Beats",
        description:
          "Listening to two slightly different frequency tones in each ear to entrain brainwaves to specific states.",
        steps: [
          "Find a quiet place where you won't be disturbed",
          "Use stereo headphones (important for the effect)",
          "Choose a binaural beat recording for relaxation (typically delta or theta waves)",
          "Close your eyes and focus on your breathing",
          "Allow your mind to follow the sounds without forcing anything",
          "Practice for 15-30 minutes",
          "After the session, take a moment to notice how you feel",
        ],
        benefits: ["Promotes deep relaxation", "Enhances meditation", "Improves focus", "Supports better sleep"],
      },
    ],
  },
]

export default function RelaxationTechniques() {
  const [activeTab, setActiveTab] = useState("breathing")
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(180) // 3 minutes in seconds

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying)
  }

  const handleReset = () => {
    setIsPlaying(false)
    setCurrentTime(0)
  }

  const handleMute = () => {
    setIsMuted(!isMuted)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
      },
    },
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-32">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
            Relaxation Techniques
          </h1>
          <p className="text-lg text-gray-700 dark:text-gray-300 mb-10 text-center">
            Explore various relaxation methods to help manage stress and improve your mental wellbeing.
          </p>

          <Tabs defaultValue="breathing" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-2 md:grid-cols-4 mb-8">
              {relaxationTechniques.map((category) => (
                <TabsTrigger key={category.id} value={category.id} className="flex items-center gap-2">
                  {category.icon} {category.title}
                </TabsTrigger>
              ))}
            </TabsList>

            {relaxationTechniques.map((category) => (
              <TabsContent key={category.id} value={category.id}>
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                >
                  {category.techniques.map((technique, index) => (
                    <motion.div key={index} variants={itemVariants}>
                      <Card className="h-full hover:shadow-md transition-shadow duration-300">
                        <CardHeader>
                          <CardTitle>{technique.name}</CardTitle>
                          <CardDescription>{technique.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div>
                            <h4 className="font-semibold mb-2">Steps:</h4>
                            <ol className="list-decimal list-inside space-y-1 text-sm">
                              {technique.steps.map((step, i) => (
                                <li key={i}>{step}</li>
                              ))}
                            </ol>
                          </div>
                          <div>
                            <h4 className="font-semibold mb-2">Benefits:</h4>
                            <ul className="list-disc list-inside space-y-1 text-sm">
                              {technique.benefits.map((benefit, i) => (
                                <li key={i}>{benefit}</li>
                              ))}
                            </ul>
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button
                            onClick={() => {
                              setIsPlaying(false)
                              setCurrentTime(0)
                            }}
                            className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                          >
                            Try Now
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>
                  ))}
                </motion.div>
              </TabsContent>
            ))}
          </Tabs>

          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-6 text-center">Guided Relaxation Timer</h2>
            <Card className="max-w-md mx-auto">
              <CardContent className="pt-6">
                <div className="flex flex-col items-center">
                  <div className="relative w-48 h-48 mb-6">
                    <div className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 opacity-20 animate-pulse-slow"></div>
                    <div className="absolute inset-2 rounded-full bg-white dark:bg-gray-900 flex items-center justify-center">
                      <div className="text-4xl font-bold">{formatTime(currentTime)}</div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4 mb-6">
                    <Button variant="outline" size="icon" onClick={handleReset}>
                      <SkipBack className="h-5 w-5" />
                    </Button>
                    <Button
                      size="icon"
                      className="h-12 w-12 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                      onClick={handlePlayPause}
                    >
                      {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                    </Button>
                    <Button variant="outline" size="icon" onClick={handleMute}>
                      {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                    </Button>
                  </div>

                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mb-4">
                    <div
                      className="bg-gradient-to-r from-purple-600 to-indigo-600 h-2.5 rounded-full"
                      style={{ width: `${(currentTime / duration) * 100}%` }}
                    ></div>
                  </div>

                  <div className="flex justify-between w-full text-sm text-gray-500 dark:text-gray-400">
                    <span>0:00</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-center">
                <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                  <Clock className="h-4 w-4 mr-1" /> Set a timer for your relaxation practice
                </p>
              </CardFooter>
            </Card>
          </div>

          <div className="mt-16 text-center">
            <h2 className="text-2xl font-bold mb-4">Need More Support?</h2>
            <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
              Try our AI chat support or connect with a professional psychologist.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild variant="outline" size="lg">
                <Link href="/chat">Chat with AI Support</Link>
              </Button>
              <Button
                asChild
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
              >
                <Link href="/psychologists">Find a Psychologist</Link>
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </ProtectedRoute>
  )
}

