"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Brain, MessageSquare, Users, Clock, PhoneCall, Sparkles, ArrowRight, Music } from "lucide-react"
import { motion } from "framer-motion"
import { useAuth } from "@/contexts/auth-context"

export default function HomePage() {
  const [mounted, setMounted] = useState(false)
  const { user } = useAuth()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const features = [
    {
      icon: <Brain className="h-10 w-10 text-purple-600" />,
      title: "Stress Evaluation",
      description:
        "Take our personalized assessment to understand your stress levels and get tailored recommendations.",
      link: "/stress-evaluation",
    },
    {
      icon: <Sparkles className="h-10 w-10 text-indigo-600" />,
      title: "Relaxation Techniques",
      description: "Explore various relaxation methods and exercises to help manage stress and anxiety.",
      link: "/relaxation",
    },
    {
      icon: <Music className="h-10 w-10 text-pink-600" />,
      title: "Mood Assessment",
      description: "Discover your current emotional state and get personalized movie and music recommendations.",
      link: "/mood",
    },
    {
      icon: <MessageSquare className="h-10 w-10 text-blue-600" />,
      title: "AI Chat Support",
      description: "Chat with our AI assistant for immediate mental health guidance and support.",
      link: "/chat",
    },
    {
      icon: <Users className="h-10 w-10 text-teal-600" />,
      title: "Top Psychologists",
      description: "Find and connect with India's top-rated mental health professionals.",
      link: "/psychologists",
    },
    {
      icon: <Clock className="h-10 w-10 text-amber-600" />,
      title: "Break Timer",
      description: "Use our timer to remind yourself to take mental health breaks throughout the day.",
      link: "/timer",
    },
    {
      icon: <PhoneCall className="h-10 w-10 text-red-600" />,
      title: "Emergency Support",
      description: "Quick access to crisis helplines and emergency mental health resources.",
      link: "/emergency",
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
      },
    },
  }

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-animation bg-gradient-to-r from-purple-100 via-blue-100 to-indigo-100 dark:from-purple-900/20 dark:via-blue-900/20 dark:to-indigo-900/20 -z-10"></div>

        <div className="container mx-auto px-4 py-20 md:py-32">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div
              className="md:w-1/2 mb-10 md:mb-0"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
                Welcome back, {user?.username || "Friend"}!
              </h1>
              <p className="text-lg md:text-xl text-gray-700 dark:text-gray-300 mb-8">
                Sukhify provides personalized tools and support to help you manage stress, find peace, and improve your
                mental wellbeing.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                >
                  <Link href="/stress-evaluation">Start Assessment</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/mood">Discover Your Mood</Link>
                </Button>
              </div>
            </motion.div>

            <motion.div
              className="md:w-1/2 flex justify-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
            >
              <div className="relative w-full max-w-md">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg blur opacity-30 animate-pulse-slow"></div>
                <div className="relative bg-white dark:bg-gray-900 rounded-lg shadow-xl overflow-hidden">
                  <img
                    src="https://i.pinimg.com/736x/f2/dd/93/f2dd93cf568a924856bef82b8428a287.jpg"
                    alt="Mental wellness illustration"
                    className="w-full h-auto animate-float"
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-900/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How Sukhify Helps You</h2>
            <p className="text-lg text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
              Our comprehensive suite of tools designed to support your mental health journey
            </p>
          </div>

          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
          >
            {features.map((feature, index) => (
              <motion.div key={index} variants={itemVariants}>
                <Card className="h-full hover:shadow-lg transition-shadow duration-300 border-none bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="mb-4">{feature.icon}</div>
                    <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">{feature.description}</p>
                    <Button asChild variant="ghost" className="group">
                      <Link href={feature.link}>
                        Explore <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Users Say</h2>
            <p className="text-lg text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
              Hear from people who have found support through Sukhify
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                quote:
                  "The mood assessment feature helped me understand my emotions better, and the movie recommendations were spot on for what I needed.",
                name: "Priya S.",
                title: "Student",
              },
              {
                quote:
                  "As a busy professional, the break timer reminds me to pause and breathe. The chat support is available whenever I need guidance.",
                name: "Rahul M.",
                title: "Software Engineer",
              },
              {
                quote:
                  "Finding a psychologist through Sukhify was easy. The platform connected me with a professional who understood my needs.",
                name: "Ananya K.",
                title: "Teacher",
              },
            ].map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full bg-white dark:bg-gray-800 border-none shadow-md">
                  <CardContent className="p-6">
                    <div className="mb-4 text-purple-600">
                      <svg width="45" height="36" className="fill-current">
                        <path d="M13.415.001C6.07 5.185.887 13.681.887 23.041c0 7.632 4.608 12.096 9.936 12.096 5.04 0 8.784-4.032 8.784-8.784 0-4.752-3.312-8.208-7.632-8.208-.864 0-2.016.144-2.304.288.72-4.896 5.328-10.656 9.936-13.536L13.415.001zm24.768 0c-7.2 5.184-12.384 13.68-12.384 23.04 0 7.632 4.608 12.096 9.936 12.096 4.896 0 8.784-4.032 8.784-8.784 0-4.752-3.456-8.208-7.776-8.208-.864 0-1.872.144-2.16.288.72-4.896 5.184-10.656 9.792-13.536L38.183.001z"></path>
                      </svg>
                    </div>
                    <p className="text-gray-700 dark:text-gray-300 mb-6 italic">"{testimonial.quote}"</p>
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center text-white font-bold">
                        {testimonial.name.charAt(0)}
                      </div>
                      <div className="ml-3">
                        <p className="font-semibold">{testimonial.name}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{testimonial.title}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start Your Wellness Journey?</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Take the first step towards better mental health today with Sukhify's personalized support.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-purple-600 hover:bg-gray-100">
                <Link href="/stress-evaluation">Take Assessment</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-white text-white hover:bg-white/10">
                <Link href="/mood">Discover Your Mood</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

