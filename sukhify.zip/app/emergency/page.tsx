"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { PhoneCall, MapPin, Clock, AlertTriangle, Search, ExternalLink } from "lucide-react"

// Define emergency contact type
interface EmergencyContact {
  id: string
  name: string
  description: string
  phone: string
  hours: string
  website?: string
  category: "crisis" | "suicide" | "addiction" | "domestic" | "child" | "general"
}

// Define crisis center type
interface CrisisCenter {
  id: string
  name: string
  address: string
  city: string
  state: string
  phone: string
  hours: string
  services: string[]
}

// Sample data for emergency contacts
const emergencyContactsData: EmergencyContact[] = [
  {
    id: "1",
    name: "National Mental Health Helpline",
    description: "24/7 toll-free helpline for mental health emergencies and support.",
    phone: "1800-599-0019",
    hours: "24/7",
    website: "https://nimhans.ac.in",
    category: "general",
  },
  {
    id: "2",
    name: "AASRA Suicide Prevention",
    description: "Crisis intervention center for the depressed and suicidal.",
    phone: "91-9820466726",
    hours: "24/7",
    website: "http://www.aasra.info",
    category: "suicide",
  },
  {
    id: "3",
    name: "Vandrevala Foundation",
    description: "Mental health support and suicide prevention helpline.",
    phone: "1860-2662-345",
    hours: "24/7",
    website: "https://www.vandrevalafoundation.com",
    category: "suicide",
  },
  {
    id: "4",
    name: "NIMHANS Center for Well-being",
    description: "Specialized mental health services and crisis intervention.",
    phone: "080-26685948",
    hours: "9 AM - 4:30 PM (Mon-Sat)",
    website: "https://nimhans.ac.in",
    category: "general",
  },
  {
    id: "5",
    name: "Sneha Suicide Prevention",
    description: "Emotional support for those in distress, feeling suicidal, or in crisis.",
    phone: "044-24640050",
    hours: "24/7",
    website: "https://www.snehaindia.org",
    category: "suicide",
  },
  {
    id: "6",
    name: "Lifeline Foundation",
    description: "Suicide prevention and crisis support helpline.",
    phone: "033-24637401",
    hours: "10 AM - 6 PM (Mon-Sat)",
    website: "https://lifelinefoundation.in",
    category: "crisis",
  },
  {
    id: "7",
    name: "National Drug Dependence Treatment Centre",
    description: "Support for substance abuse and addiction.",
    phone: "011-26593236",
    hours: "9 AM - 5 PM (Mon-Fri)",
    website:
      "https://aiims.edu/en/departments-and-centers/central-facilities/1084-national-drug-dependence-treatment-centre-nddtc.html",
    category: "addiction",
  },
  {
    id: "8",
    name: "Women's Helpline",
    description: "Support for women facing domestic violence or abuse.",
    phone: "1091",
    hours: "24/7",
    category: "domestic",
  },
  {
    id: "9",
    name: "CHILDLINE India",
    description: "Emergency helpline for children in distress.",
    phone: "1098",
    hours: "24/7",
    website: "https://www.childlineindia.org",
    category: "child",
  },
]

// Sample data for crisis centers
const crisisCentersData: CrisisCenter[] = [
  {
    id: "1",
    name: "NIMHANS Emergency Psychiatric Care",
    address: "Hosur Road, Bengaluru",
    city: "Bangalore",
    state: "Karnataka",
    phone: "080-26995100",
    hours: "24/7",
    services: ["Emergency Psychiatric Care", "Crisis Intervention", "Inpatient Services"],
  },
  {
    id: "2",
    name: "Institute of Human Behaviour & Allied Sciences",
    address: "Dilshad Garden, Delhi",
    city: "Delhi",
    state: "Delhi",
    phone: "011-22114029",
    hours: "24/7",
    services: ["Psychiatric Emergency", "Addiction Treatment", "Neuropsychiatric Care"],
  },
  {
    id: "3",
    name: "KEM Hospital Psychiatric Department",
    address: "Parel, Mumbai",
    city: "Mumbai",
    state: "Maharashtra",
    phone: "022-24107000",
    hours: "24/7",
    services: ["Crisis Management", "Psychiatric Emergency", "Mental Health Support"],
  },
  {
    id: "4",
    name: "Schizophrenia Research Foundation (SCARF)",
    address: "R/7A, North Main Road, Anna Nagar West, Chennai",
    city: "Chennai",
    state: "Tamil Nadu",
    phone: "044-26153971",
    hours: "9 AM - 5 PM (Mon-Sat)",
    services: ["Crisis Support", "Rehabilitation", "Outpatient Services"],
  },
  {
    id: "5",
    name: "Central Institute of Psychiatry",
    address: "Kanke, Ranchi",
    city: "Ranchi",
    state: "Jharkhand",
    phone: "0651-2233008",
    hours: "24/7",
    services: ["Emergency Psychiatric Care", "Inpatient Treatment", "Rehabilitation"],
  },
  {
    id: "6",
    name: "LGB Regional Institute of Mental Health",
    address: "Tezpur",
    city: "Tezpur",
    state: "Assam",
    phone: "03712-233623",
    hours: "24/7",
    services: ["Crisis Intervention", "Emergency Care", "Mental Health Services"],
  },
  {
    id: "7",
    name: "Institute of Mental Health",
    address: "Erragadda, Hyderabad",
    city: "Hyderabad",
    state: "Telangana",
    phone: "040-23814270",
    hours: "24/7",
    services: ["Psychiatric Emergency", "Inpatient Care", "Outpatient Services"],
  },
  {
    id: "8",
    name: "Institute of Psychiatry and Human Behaviour",
    address: "Bambolim, Goa",
    city: "Panaji",
    state: "Goa",
    phone: "0832-2458700",
    hours: "24/7",
    services: ["Emergency Services", "Crisis Management", "Mental Health Support"],
  },
]

export default function EmergencySupport() {
  const [activeTab, setActiveTab] = useState("helplines")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all-categories")
  const [selectedState, setSelectedState] = useState("")

  // Get unique categories for filter
  const categories = [
    { value: "crisis", label: "Crisis Support" },
    { value: "suicide", label: "Suicide Prevention" },
    { value: "addiction", label: "Addiction Support" },
    { value: "domestic", label: "Domestic Violence" },
    { value: "child", label: "Child Support" },
    { value: "general", label: "General Mental Health" },
  ]

  // Get unique states for filter
  const states = Array.from(new Set(crisisCentersData.map((center) => center.state))).sort()

  // Filter emergency contacts
  const filteredContacts = emergencyContactsData.filter((contact) => {
    const matchesSearch =
      searchTerm === "" ||
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.description.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesCategory = selectedCategory === "all-categories" || contact.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  // Filter crisis centers
  const filteredCenters = crisisCentersData.filter((center) => {
    const matchesSearch =
      searchTerm === "" ||
      center.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      center.services.some((service) => service.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesState = selectedState === "" || center.state === selectedState

    return matchesSearch && matchesState
  })

  return (
    <div className="container mx-auto px-4 py-32">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <div className="max-w-4xl mx-auto">
          <div className="bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 rounded-lg p-6 mb-10">
            <div className="flex items-start">
              <div className="mr-4">
                <div className="h-12 w-12 rounded-full bg-red-100 dark:bg-red-900 flex items-center justify-center">
                  <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400" />
                </div>
              </div>
              <div>
                <h2 className="text-xl font-bold text-red-800 dark:text-red-400 mb-2">In case of immediate danger</h2>
                <p className="text-red-700 dark:text-red-300 mb-4">
                  If you or someone you know is in immediate danger or at risk of harming themselves or others, please:
                </p>
                <ul className="list-disc list-inside space-y-1 text-red-700 dark:text-red-300 mb-4">
                  <li>
                    Call emergency services: <strong>112</strong> or <strong>108</strong>
                  </li>
                  <li>Go to your nearest emergency room</li>
                  <li>
                    Call the National Mental Health Helpline: <strong>1800-599-0019</strong>
                  </li>
                </ul>
                <p className="text-red-700 dark:text-red-300">Don't wait. Reach out for help immediately.</p>
              </div>
            </div>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
            Emergency Support
          </h1>
          <p className="text-lg text-gray-700 dark:text-gray-300 mb-10 text-center">
            Access immediate mental health support resources and crisis intervention services.
          </p>

          <Tabs defaultValue="helplines" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="helplines" className="flex items-center gap-2">
                <PhoneCall className="h-4 w-4" /> Helplines
              </TabsTrigger>
              <TabsTrigger value="centers" className="flex items-center gap-2">
                <MapPin className="h-4 w-4" /> Crisis Centers
              </TabsTrigger>
            </TabsList>

            <TabsContent value="helplines">
              <div className="mb-6 flex flex-col md:flex-row gap-4">
                <div className="relative flex-grow">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Search helplines..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>

                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full md:w-[200px]">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-categories">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {filteredContacts.length > 0 ? (
                <motion.div
                  variants={{
                    hidden: { opacity: 0 },
                    show: {
                      opacity: 1,
                      transition: {
                        staggerChildren: 0.1,
                      },
                    },
                  }}
                  initial="hidden"
                  animate="show"
                  className="space-y-4"
                >
                  {filteredContacts.map((contact) => (
                    <motion.div
                      key={contact.id}
                      variants={{
                        hidden: { opacity: 0, y: 20 },
                        show: { opacity: 1, y: 0 },
                      }}
                    >
                      <Card>
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <div>
                              <CardTitle>{contact.name}</CardTitle>
                              <CardDescription className="mt-1">{contact.description}</CardDescription>
                            </div>
                            <Badge
                              variant="outline"
                              className={
                                contact.category === "crisis"
                                  ? "border-orange-500 text-orange-700 dark:text-orange-400"
                                  : contact.category === "suicide"
                                    ? "border-red-500 text-red-700 dark:text-red-400"
                                    : contact.category === "addiction"
                                      ? "border-blue-500 text-blue-700 dark:text-blue-400"
                                      : contact.category === "domestic"
                                        ? "border-purple-500 text-purple-700 dark:text-purple-400"
                                        : contact.category === "child"
                                          ? "border-green-500 text-green-700 dark:text-green-400"
                                          : "border-gray-500 text-gray-700 dark:text-gray-400"
                              }
                            >
                              {categories.find((c) => c.value === contact.category)?.label}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                            <div className="flex items-center">
                              <PhoneCall className="h-5 w-5 text-red-600 mr-2" />
                              <span className="font-semibold">{contact.phone}</span>
                            </div>
                            <div className="flex items-center">
                              <Clock className="h-5 w-5 text-gray-500 mr-2" />
                              <span>{contact.hours}</span>
                            </div>
                          </div>
                        </CardContent>
                        {contact.website && (
                          <CardFooter>
                            <Button
                              variant="outline"
                              size="sm"
                              className="w-full"
                              onClick={() => window.open(contact.website, "_blank")}
                            >
                              Visit Website <ExternalLink className="h-4 w-4 ml-2" />
                            </Button>
                          </CardFooter>
                        )}
                      </Card>
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <h3 className="text-xl font-semibold mb-2">No helplines found</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">Try adjusting your search or filters</p>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchTerm("")
                      setSelectedCategory("all-categories")
                    }}
                  >
                    Clear Filters
                  </Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="centers">
              <div className="mb-6 flex flex-col md:flex-row gap-4">
                <div className="relative flex-grow">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Search crisis centers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>

                <Select value={selectedState} onValueChange={setSelectedState}>
                  <SelectTrigger className="w-full md:w-[200px]">
                    <SelectValue placeholder="All States" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-states">All States</SelectItem>
                    {states.map((state) => (
                      <SelectItem key={state} value={state}>
                        {state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {filteredCenters.length > 0 ? (
                <motion.div
                  variants={{
                    hidden: { opacity: 0 },
                    show: {
                      opacity: 1,
                      transition: {
                        staggerChildren: 0.1,
                      },
                    },
                  }}
                  initial="hidden"
                  animate="show"
                  className="space-y-4"
                >
                  {filteredCenters.map((center) => (
                    <motion.div
                      key={center.id}
                      variants={{
                        hidden: { opacity: 0, y: 20 },
                        show: { opacity: 1, y: 0 },
                      }}
                    >
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle>{center.name}</CardTitle>
                          <CardDescription>
                            {center.address}, {center.city}, {center.state}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                            <div className="flex items-center">
                              <PhoneCall className="h-5 w-5 text-red-600 mr-2" />
                              <span className="font-semibold">{center.phone}</span>
                            </div>
                            <div className="flex items-center">
                              <Clock className="h-5 w-5 text-gray-500 mr-2" />
                              <span>{center.hours}</span>
                            </div>
                          </div>
                          <div className="mt-4">
                            <h4 className="font-semibold mb-1">Services:</h4>
                            <ul className="list-disc list-inside text-sm">
                              {center.services.map((service, index) => (
                                <li key={index}>{service}</li>
                              ))}
                            </ul>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <h3 className="text-xl font-semibold mb-2">No crisis centers found</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">Try adjusting your search or filters</p>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchTerm("")
                      setSelectedState("")
                    }}
                  >
                    Clear Filters
                  </Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </motion.div>
    </div>
  )
}

