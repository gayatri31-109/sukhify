"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import {
  ArrowLeft,
  ArrowRight,
  Music,
  Film,
  Heart,
  ThumbsUp,
  RefreshCcw,
  Smile,
  Frown,
  Meh,
  SmilePlus,
  FrownIcon as FrownPlus,
} from "lucide-react"

// Define mood types
type Mood = "happy" | "calm" | "sad" | "anxious" | "angry" | "neutral"

// Define mood assessment methods
type AssessmentMethod = "direct" | "visual" | "questions" | "sliders"

// Define media recommendation
interface MediaRecommendation {
  title: string
  creator: string
  year?: string
  genre: string
  description: string
  mood: Mood
  image: string
}

// Sample movie recommendations based on mood
const movieRecommendations: Record<Mood, MediaRecommendation[]> = {
  happy: [
    {
      title: "La La Land",
      creator: "Damien Chazelle",
      year: "2016",
      genre: "Musical/Romance",
      description: "A feel-good musical about dreamers in Los Angeles with vibrant colors and uplifting songs.",
      mood: "happy",
      image: "https://i.pinimg.com/474x/03/52/aa/0352aa6a65f07795d1215432cdb5f4a0.jpg",
      imageDimensions:{
      height:200,
      width:150
    },\
    {
      title: "The Secret Life of Walter Mitty",
      creator: "Ben Stiller",
      year: "2013",
      genre: "Adventure/Comedy",
      description: "An uplifting story about stepping out of your comfort zone and embracing life's adventures.",
      mood: "happy",
      image: "https://i.pinimg.com/474x/d0/4d/b6/d04db6f0e85297123330934286b2a0be.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "Sing Street",
      creator: "John Carney",
      year: "2016",
      genre: "Musical/Comedy",
      description:
        "A heartwarming story about a boy who forms a band to impress a girl, filled with catchy 80s-inspired songs.",
      mood: "happy",
      image: "https://i.pinimg.com/474x/9a/2f/9d/9a2f9dce2ae0921a00b372fc93f46e51.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
  ],
  calm: [
    {
      title: "The Secret Garden",
      creator: "Marc Munden",
      year: "2020",
      genre: "Drama/Fantasy",
      description: "A peaceful adaptation of the classic novel with beautiful garden scenes and a soothing atmosphere.",
      mood: "calm",
      image: "https://i.pinimg.com/474x/0b/eb/7b/0beb7b30883a12d9a5e7e58fc757757e.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "Chef",
      creator: "Jon Favreau",
      year: "2014",
      genre: "Comedy/Drama",
      description: "A relaxing journey of food and family as a chef rediscovers his passion through a food truck.",
      mood: "calm",
      image: "https://i.pinimg.com/474x/23/62/c7/2362c7ee944afd656a066d6ab7a22deb.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "Amélie",
      creator: "Jean-Pierre Jeunet",
      year: "2001",
      genre: "Romance/Comedy",
      description:
        "A whimsical French film with a gentle pace and beautiful visuals about finding joy in small things.",
      mood: "calm",
      image: "https://i.pinimg.com/474x/d8/9e/ac/d89eac7350c0c7d61b8ca8b22863c398.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
  ],
  sad: [
    {
      title: "The Pursuit of Happyness",
      creator: "Gabriele Muccino",
      year: "2006",
      genre: "Drama/Biography",
      description: "An inspiring true story of perseverance through hardship that might help process sadness.",
      mood: "sad",
      image: "https://i.pinimg.com/474x/dd/4f/a0/dd4fa0752e4662e768e441f8d748492f.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "Inside Out",
      creator: "Pete Docter",
      year: "2015",
      genre: "Animation/Comedy",
      description: "A Pixar film that beautifully illustrates the importance of all emotions, including sadness.",
      mood: "sad",
      image: "https://i.pinimg.com/474x/29/33/af/2933af00a7e2ac8f8a28a92e94ac11ce.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "Good Will Hunting",
      creator: "Gus Van Sant",
      year: "1997",
      genre: "Drama",
      description:
        "A moving story about overcoming past trauma and finding connection that validates emotional struggles.",
      mood: "sad",
      image: "https://i.pinimg.com/474x/a5/89/06/a58906a49c310a7d8ec07bdec8f00dbb.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
  ],
  anxious: [
    {
      title: "Soul",
      creator: "Pete Docter",
      year: "2020",
      genre: "Animation/Comedy",
      description: "A thoughtful Pixar film about finding your purpose and appreciating the simple joys of life.",
      mood: "anxious",
      image: "https://i.pinimg.com/474x/ac/7a/b6/ac7ab6ed58df992a4750968f39584501.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "The Truman Show",
      creator: "Peter Weir",
      year: "1998",
      genre: "Comedy/Drama",
      description: "A thought-provoking film that might help put anxieties about life and reality in perspective.",
      mood: "anxious",
      image: "https://i.pinimg.com/474x/10/d4/68/10d46842ab1d27b99c6ec906f38bc093.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "Big Hero 6",
      creator: "Don Hall, Chris Williams",
      year: "2014",
      genre: "Animation/Action",
      description: "A heartwarming story about healing, friendship, and a healthcare companion robot.",
      mood: "anxious",
      image: "https://i.pinimg.com/474x/0d/10/b0/0d10b08f9990dd2354c0256a7172b2c5.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
  ],
  angry: [
    {
      title: "The Karate Kid",
      creator: "John G. Avildsen",
      year: "1984",
      genre: "Drama/Action",
      description: "A classic underdog story about channeling frustration into discipline and skill.",
      mood: "angry",
      image: "https://i.pinimg.com/474x/7e/3f/eb/7e3febb90b88a3b1b253dee3ce69f133.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "School of Rock",
      creator: "Richard Linklater",
      year: "2003",
      genre: "Comedy/Music",
      description: "A fun, energetic film about expressing yourself through music that might help redirect anger.",
      mood: "angry",
      image: "https://i.pinimg.com/474x/fd/53/ec/fd53ec506f8339b7d44ededef7549f0b.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "Legally Blonde",
      creator: "Robert Luketic",
      year: "2001",
      genre: "Comedy/Romance",
      description: "An empowering story about proving doubters wrong and succeeding against expectations.",
      mood: "angry",
      image: "https://i.pinimg.com/474x/c8/d4/a4/c8d4a40c707edeae45b66cc2c91223dc.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
  ],
  neutral: [
    {
      title: "The Grand Budapest Hotel",
      creator: "Wes Anderson",
      year: "2014",
      genre: "Comedy/Drama",
      description: "A visually stunning and quirky adventure with a unique style and engaging story.",
      mood: "neutral",
      image: "https://i.pinimg.com/474x/b8/42/ad/b842ad05a0baaf00d42fdae43f243abc.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "The Princess Bride",
      creator: "Rob Reiner",
      year: "1987",
      genre: "Adventure/Fantasy",
      description: "A timeless, entertaining tale of adventure, romance, and humor suitable for any mood.",
      mood: "neutral",
      image: "https://i.pinimg.com/474x/28/55/1e/28551efc1b355697208db38678f1618e.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
    {
      title: "Ferris Bueller's Day Off",
      creator: "John Hughes",
      year: "1986",
      genre: "Comedy",
      description: "A classic comedy about taking a break and enjoying life that can lift any neutral mood.",
      mood: "neutral",
      image: "https://i.pinimg.com/474x/4e/9e/ed/4e9eedcbca3cd230e9f4c427146d6cbd.jpg",
      imageDimensions:{
      height:200,
      width:150
    },
    },
  ],
}

// Sample song recommendations based on mood
const songRecommendations: Record<Mood, MediaRecommendation[]> = {
  happy: [
    {
      title: "Happy",
      creator: "Pharrell Williams",
      year: "2013",
      genre: "Pop",
      description: "An infectious, upbeat song that celebrates happiness and positivity.",
      mood: "happy",
      image: "https://i.pinimg.com/474x/29/4f/88/294f88f8b6005b82e33d9cefa6fed737.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Walking on Sunshine",
      creator: "Katrina and The Waves",
      year: "1985",
      genre: "Pop/Rock",
      description: "A classic feel-good song with bright energy and joyful lyrics.",
      mood: "happy",
      image: "https://i.pinimg.com/474x/70/58/3c/70583c39a86dae909d29b382b4d83645.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Can't Stop the Feeling!",
      creator: "Justin Timberlake",
      year: "2016",
      genre: "Pop",
      description: "A danceable pop hit with uplifting lyrics about joy and good vibes.",
      mood: "happy",
      image: "https://i.pinimg.com/474x/cc/f0/56/ccf056862f28c1b56fd335d8d1d714e8.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
  ],
  calm: [
    {
      title: "Weightless",
      creator: "Marconi Union",
      year: "2011",
      genre: "Ambient",
      description: "Scientifically designed to reduce anxiety and induce a state of calm.",
      mood: "calm",
      image: "https://i.pinimg.com/474x/cc/f0/56/ccf056862f28c1b56fd335d8d1d714e8.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Claire de Lune",
      creator: "Claude Debussy",
      year: "1905",
      genre: "Classical",
      description: "A gentle, flowing piano piece that creates a peaceful atmosphere.",
      mood: "calm",
      image: "https://i.pinimg.com/474x/7e/fd/3b/7efd3bf81c3920d3ee579bf056b7bdbe.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Holocene",
      creator: "Bon Iver",
      year: "2011",
      genre: "Indie Folk",
      description: "A serene, atmospheric song with gentle instrumentation and soothing vocals.",
      mood: "calm",
      image: "https://i.pinimg.com/474x/e4/eb/ad/e4ebad12a91c656557f5770a2f71a7d0.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
  ],
  sad: [
    {
      title: "Someone Like You",
      creator: "Adele",
      year: "2011",
      genre: "Pop/Soul",
      description: "A powerful ballad about acceptance and moving on that resonates with sadness.",
      mood: "sad",
      image: "https://i.pinimg.com/474x/37/54/fb/3754fbfc334d3975cec66c9229300037.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Fix You",
      creator: "Coldplay",
      year: "2005",
      genre: "Alternative Rock",
      description: "An emotional song about helping someone through difficult times with an uplifting climax.",
      mood: "sad",
      image: "https://i.pinimg.com/474x/aa/2b/cb/aa2bcb9dabe2aea26bb54290ad836613.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Hurt",
      creator: "Johnny Cash",
      year: "2002",
      genre: "Country/Folk",
      description: "A raw, emotional cover that explores themes of regret and reflection.",
      mood: "sad",
      image: "https://i.pinimg.com/474x/04/34/49/0434492aa9a6d7d67b4cb3a061733c7a.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
  ],
  anxious: [
    {
      title: "Breathe Me",
      creator: "Sia",
      year: "2004",
      genre: "Pop",
      description: "A vulnerable song about needing support that can help process anxiety.",
      mood: "anxious",
      image: "https://i.pinimg.com/736x/ca/c8/31/cac831f3987c61f3d4a8061a300559cd.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Orinoco Flow",
      creator: "Enya",
      year: "1988",
      genre: "New Age",
      description: "A flowing, ethereal piece that creates a sense of calm and escape.",
      mood: "anxious",
      image: "https://i.pinimg.com/474x/e8/7b/5a/e87b5a3a1842fade06cb1c5f58404436.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Everything's Alright",
      creator: "Laura Shigihara",
      year: "2011",
      genre: "Indie",
      description: "A gentle reassurance that things will be okay, perfect for anxious moments.",
      mood: "anxious",
      image: "https://i.pinimg.com/474x/e2/9f/c7/e29fc7e312e871a3abe6b99ebe92f09a.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
  ],
  angry: [
    {
      title: "Stronger",
      creator: "Kelly Clarkson",
      year: "2011",
      genre: "Pop/Rock",
      description: "An empowering anthem about becoming stronger through adversity.",
      mood: "angry",
      image: "https://i.pinimg.com/474x/02/32/0c/02320cae26f1f7831cb9327365053f32.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Eye of the Tiger",
      creator: "Survivor",
      year: "1982",
      genre: "Rock",
      description: "A motivational classic about determination and overcoming challenges.",
      mood: "angry",
      image: "https://i.pinimg.com/474x/da/71/80/da71807f958a2a8d36ddd761767d569d.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Fight Song",
      creator: "Rachel Platten",
      year: "2015",
      genre: "Pop",
      description: "An uplifting song about standing up for yourself and finding your strength.",
      mood: "angry",
      image: "/placeholder.svg?height=200&width=150",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
  ],
  neutral: [
    {
      title: "Here Comes the Sun",
      creator: "The Beatles",
      year: "1969",
      genre: "Rock/Pop",
      description: "A gentle, optimistic song that can brighten a neutral mood.",
      mood: "neutral",
      image: "https://i.pinimg.com/474x/2c/6c/e3/2c6ce373183b9f6cf118e4da1458b4d3.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "Somewhere Over the Rainbow",
      creator: "Israel Kamakawiwoʻole",
      year: "1993",
      genre: "Folk",
      description: "A beautiful, hopeful rendition that inspires wonder and possibility.",
      mood: "neutral",
      image: "https://i.pinimg.com/474x/cb/21/8c/cb218c67a863195cff5239c23e6fef92.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
    {
      title: "What a Wonderful World",
      creator: "Louis Armstrong",
      year: "1967",
      genre: "Jazz",
      description: "A timeless classic celebrating the beauty in everyday life.",
      mood: "neutral",
      image: "https://i.pinimg.com/474x/d7/df/b0/d7dfb06b0cb3ac65edeed3f9e67cb4d0.jpg",
      imageDimensions: {
        height: 200,
        width: 150,
      },
    },
  ],
}

// Mood assessment questions
const moodQuestions = [
  "How would you describe your energy level right now?",
  "What thoughts have been occupying your mind today?",
  "How connected do you feel to others at the moment?",
  "What would make you feel better right now?",
]

// Visual mood assessment images
const moodImages = [
  {
    id: "img1",
    src: "https://i.pinimg.com/474x/78/5e/76/785e7639f3b94a6f1302eaf7c645777d.jpg",
    mood: "happy",
    description: "Sunny beach",
    width: 200,
    height: 200,
  },
  {
    id: "img2",
    src: "https://i.pinimg.com/474x/82/ff/b5/82ffb56c707f02b3f7a976c1e73eeac6.jpg",
    mood: "calm",
    description: "Peaceful forest",
    width: 200,
    height: 200,
  },
  {
    id: "img3",
    src: "https://i.pinimg.com/474x/15/65/7b/15657b7ce062a029a790efc27dad8595.jpg",
    mood: "sad",
    description: "Rainy window",
    width: 200,
    height: 200,
  },
  {
    id: "img4",
    src: "https://i.pinimg.com/474x/7d/ec/53/7dec53373b9167c615b1963ba877ccc7.jpg",
    mood: "anxious",
    description: "Stormy sea",
    width: 200,
    height: 200,
  },
  {
    id: "img5",
    src: "https://i.pinimg.com/474x/2c/93/62/2c936242f8a21cd7341f1ea41dbce71c.jpg",
    mood: "angry",
    description: "Volcanic eruption",
    width: 200,
    height: 200,
  },
  {
    id: "img6",
    src: "https://i.pinimg.com/474x/1c/f0/a3/1cf0a3cca44aaca4487bbf599d7f18af.jpg",
    mood: "neutral",
    description: "Cloudy sky",
    width: 200,
    height: 200,
  },
]

export default function MoodAssessment() {
  const [step, setStep] = useState(1)
  const [assessmentMethod, setAssessmentMethod] = useState<AssessmentMethod>("direct")
  const [currentMood, setCurrentMood] = useState<Mood | null>(null)
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [moodIntensity, setMoodIntensity] = useState<number>(50)
  const [moodEnergy, setMoodEnergy] = useState<number>(50)
  const [recommendationsTab, setRecommendationsTab] = useState<"movies" | "songs">("movies")

  // Get mood icon based on mood type
  const getMoodIcon = (mood: Mood) => {
    switch (mood) {
      case "happy":
        return <SmilePlus className="h-6 w-6" />
      case "calm":
        return <Smile className="h-6 w-6" />
      case "sad":
        return <Frown className="h-6 w-6" />
      case "anxious":
        return <Meh className="h-6 w-6 rotate-180" />
      case "angry":
        return <FrownPlus className="h-6 w-6" />
      case "neutral":
        return <Meh className="h-6 w-6" />
      default:
        return <Meh className="h-6 w-6" />
    }
  }

  // Get mood color based on mood type
  const getMoodColor = (mood: Mood) => {
    switch (mood) {
      case "happy":
        return "bg-yellow-500"
      case "calm":
        return "bg-blue-500"
      case "sad":
        return "bg-indigo-500"
      case "anxious":
        return "bg-orange-500"
      case "angry":
        return "bg-red-500"
      case "neutral":
        return "bg-gray-500"
      default:
        return "bg-gray-500"
    }
  }

  // Get mood description based on mood type
  const getMoodDescription = (mood: Mood) => {
    switch (mood) {
      case "happy":
        return "You're feeling positive and upbeat. This is a great time to engage in creative activities or connect with others."
      case "calm":
        return "You're in a peaceful and relaxed state. This is an ideal time for reflection, meditation, or gentle activities."
      case "sad":
        return "You're experiencing feelings of sadness. Remember that all emotions are valid and temporary. Gentle self-care may help."
      case "anxious":
        return "You're feeling worried or uneasy. Grounding techniques and mindful breathing might help reduce these feelings."
      case "angry":
        return "You're experiencing frustration or anger. Physical activities or creative expression might help channel these emotions."
      case "neutral":
        return "You're in a balanced emotional state. This is a good time for routine tasks or trying something new."
      default:
        return ""
    }
  }

  // Handle direct mood selection
  const handleMoodSelect = (mood: Mood) => {
    setCurrentMood(mood)
  }

  // Handle image selection for visual assessment
  const handleImageSelect = (imageId: string) => {
    setSelectedImage(imageId)
    const selectedMoodImage = moodImages.find((img) => img.id === imageId)
    if (selectedMoodImage) {
      setCurrentMood(selectedMoodImage.mood as Mood)
    }
  }

  // Handle question answers
  const handleAnswerChange = (questionIndex: number, answer: string) => {
    setAnswers({ ...answers, [questionIndex]: answer })
  }

  // Determine mood from questionnaire answers
  const determineMoodFromAnswers = () => {
    // This is a simplified algorithm - in a real app, this would be more sophisticated
    const answerText = Object.values(answers).join(" ").toLowerCase()

    if (answerText.includes("happy") || answerText.includes("joy") || answerText.includes("excited")) {
      return "happy"
    } else if (answerText.includes("calm") || answerText.includes("peace") || answerText.includes("relax")) {
      return "calm"
    } else if (answerText.includes("sad") || answerText.includes("down") || answerText.includes("blue")) {
      return "sad"
    } else if (answerText.includes("anxious") || answerText.includes("worry") || answerText.includes("stress")) {
      return "anxious"
    } else if (answerText.includes("angry") || answerText.includes("frustrat") || answerText.includes("annoy")) {
      return "angry"
    } else {
      return "neutral"
    }
  }

  // Determine mood from slider values
  const determineMoodFromSliders = () => {
    // High intensity + high energy = happy
    if (moodIntensity > 70 && moodEnergy > 70) return "happy"
    // Low intensity + medium-high energy = calm
    if (moodIntensity < 30 && moodEnergy > 40) return "calm"
    // High intensity + low energy = sad
    if (moodIntensity > 60 && moodEnergy < 30) return "sad"
    // Medium-high intensity + medium energy = anxious
    if (moodIntensity > 60 && moodEnergy > 30 && moodEnergy < 60) return "anxious"
    // High intensity + medium-high energy = angry
    if (moodIntensity > 80 && moodEnergy > 50) return "angry"
    // Medium values = neutral
    return "neutral"
  }

  // Handle next step in assessment
  const handleNext = () => {
    if (step === 1) {
      setStep(2)
    } else if (step === 2) {
      if (assessmentMethod === "direct" && currentMood) {
        setStep(3)
      } else if (assessmentMethod === "visual" && selectedImage) {
        setStep(3)
      } else if (assessmentMethod === "questions") {
        if (currentQuestionIndex < moodQuestions.length - 1) {
          setCurrentQuestionIndex(currentQuestionIndex + 1)
        } else {
          // Determine mood from questionnaire
          const mood = determineMoodFromAnswers()
          setCurrentMood(mood as Mood)
          setStep(3)
        }
      } else if (assessmentMethod === "sliders") {
        // Determine mood from sliders
        const mood = determineMoodFromSliders()
        setCurrentMood(mood as Mood)
        setStep(3)
      }
    }
  }

  // Handle previous step in assessment
  const handlePrevious = () => {
    if (step === 2) {
      if (assessmentMethod === "questions" && currentQuestionIndex > 0) {
        setCurrentQuestionIndex(currentQuestionIndex - 1)
      } else {
        setStep(1)
      }
    } else if (step === 3) {
      setStep(2)
    }
  }

  // Handle restart of assessment
  const handleRestart = () => {
    setStep(1)
    setAssessmentMethod("direct")
    setCurrentMood(null)
    setSelectedImage(null)
    setAnswers({})
    setCurrentQuestionIndex(0)
    setMoodIntensity(50)
    setMoodEnergy(50)
  }

  return (
    <div className="container mx-auto px-4 py-32">
      <div className="max-w-4xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
            Mood Assessment & Recommendations
          </h1>
          <p className="text-lg text-gray-700 dark:text-gray-300 mb-10 text-center">
            Discover your current emotional state and get personalized movie and music recommendations to match your
            mood.
          </p>
        </motion.div>

        {step === 1 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Choose Assessment Method</CardTitle>
                <CardDescription>Select how you'd like to assess your current mood</CardDescription>
              </CardHeader>
              <CardContent>
                <RadioGroup
                  value={assessmentMethod}
                  onValueChange={(value) => setAssessmentMethod(value as AssessmentMethod)}
                  className="space-y-4"
                >
                  <div className="flex items-center space-x-2 rounded-md border p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                    <RadioGroupItem value="direct" id="direct" />
                    <Label htmlFor="direct" className="flex-grow cursor-pointer">
                      <div className="font-medium mb-1">Direct Selection</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        Choose your mood directly from a list of emotions
                      </div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2 rounded-md border p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                    <RadioGroupItem value="visual" id="visual" />
                    <Label htmlFor="visual" className="flex-grow cursor-pointer">
                      <div className="font-medium mb-1">Visual Assessment</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        Select images that resonate with your current feelings
                      </div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2 rounded-md border p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                    <RadioGroupItem value="questions" id="questions" />
                    <Label htmlFor="questions" className="flex-grow cursor-pointer">
                      <div className="font-medium mb-1">Questionnaire</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        Answer a few questions about your current state of mind
                      </div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2 rounded-md border p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                    <RadioGroupItem value="sliders" id="sliders" />
                    <Label htmlFor="sliders" className="flex-grow cursor-pointer">
                      <div className="font-medium mb-1">Emotion Sliders</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        Use sliders to indicate your emotional intensity and energy
                      </div>
                    </Label>
                  </div>
                </RadioGroup>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button
                  onClick={handleNext}
                  className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                >
                  Continue <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        )}

        {step === 2 && (
          <AnimatePresence mode="wait">
            {assessmentMethod === "direct" && (
              <motion.div
                key="direct"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>How are you feeling right now?</CardTitle>
                    <CardDescription>Select the emotion that best describes your current mood</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {(["happy", "calm", "sad", "anxious", "angry", "neutral"] as Mood[]).map((mood) => (
                        <div
                          key={mood}
                          className={`flex flex-col items-center p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            currentMood === mood
                              ? `border-purple-500 bg-purple-50 dark:bg-purple-900/20`
                              : `border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-700`
                          }`}
                          onClick={() => handleMoodSelect(mood)}
                        >
                          <div
                            className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${getMoodColor(mood)} text-white`}
                          >
                            {getMoodIcon(mood)}
                          </div>
                          <span className="font-medium capitalize">{mood}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={handlePrevious}>
                      <ArrowLeft className="mr-2 h-4 w-4" /> Back
                    </Button>
                    <Button
                      onClick={handleNext}
                      disabled={!currentMood}
                      className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                    >
                      Continue <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            )}

            {assessmentMethod === "visual" && (
              <motion.div
                key="visual"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Which image resonates with you most?</CardTitle>
                    <CardDescription>Select the image that best reflects your current emotional state</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {moodImages.map((image) => (
                        <div
                          key={image.id}
                          className={`relative rounded-lg overflow-hidden cursor-pointer transition-all ${
                            selectedImage === image.id ? `ring-4 ring-purple-500` : `hover:opacity-90`
                          }`}
                          onClick={() => handleImageSelect(image.id)}
                        >
                          <img
                            src={image.src || "/placeholder.svg"}
                            alt={image.description}
                            className="w-full h-40 object-cover"
                          />
                          {selectedImage === image.id && (
                            <div className="absolute inset-0 bg-purple-500/30 flex items-center justify-center">
                              <ThumbsUp className="h-8 w-8 text-white" />
                            </div>
                          )}
                          <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-2 text-sm">
                            {image.description}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={handlePrevious}>
                      <ArrowLeft className="mr-2 h-4 w-4" /> Back
                    </Button>
                    <Button
                      onClick={handleNext}
                      disabled={!selectedImage}
                      className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                    >
                      Continue <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            )}

            {assessmentMethod === "questions" && (
              <motion.div
                key="questions"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-center mb-2">
                      <div className="text-sm font-medium text-gray-500 dark:text-gray-400">
                        Question {currentQuestionIndex + 1} of {moodQuestions.length}
                      </div>
                    </div>
                    <Progress value={((currentQuestionIndex + 1) / moodQuestions.length) * 100} className="h-2 mb-4" />
                    <CardTitle className="text-xl">{moodQuestions[currentQuestionIndex]}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      placeholder="Type your answer here..."
                      value={answers[currentQuestionIndex] || ""}
                      onChange={(e) => handleAnswerChange(currentQuestionIndex, e.target.value)}
                      className="min-h-[120px]"
                    />
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={handlePrevious}>
                      <ArrowLeft className="mr-2 h-4 w-4" /> Back
                    </Button>
                    <Button
                      onClick={handleNext}
                      disabled={!answers[currentQuestionIndex]}
                      className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                    >
                      {currentQuestionIndex < moodQuestions.length - 1 ? (
                        <>
                          Next <ArrowRight className="ml-2 h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Complete <ThumbsUp className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            )}

            {assessmentMethod === "sliders" && (
              <motion.div
                key="sliders"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Rate Your Emotional State</CardTitle>
                    <CardDescription>
                      Use the sliders to indicate the intensity and energy of your current emotions
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label htmlFor="intensity">Emotional Intensity</Label>
                        <span className="text-sm font-medium">{moodIntensity}%</span>
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-500">Mild</span>
                        <Slider
                          id="intensity"
                          min={0}
                          max={100}
                          step={1}
                          value={[moodIntensity]}
                          onValueChange={(value) => setMoodIntensity(value[0])}
                          className="flex-grow"
                        />
                        <span className="text-sm text-gray-500">Intense</span>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label htmlFor="energy">Energy Level</Label>
                        <span className="text-sm font-medium">{moodEnergy}%</span>
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-500">Low</span>
                        <Slider
                          id="energy"
                          min={0}
                          max={100}
                          step={1}
                          value={[moodEnergy]}
                          onValueChange={(value) => setMoodEnergy(value[0])}
                          className="flex-grow"
                        />
                        <span className="text-sm text-gray-500">High</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={handlePrevious}>
                      <ArrowLeft className="mr-2 h-4 w-4" /> Back
                    </Button>
                    <Button
                      onClick={handleNext}
                      className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                    >
                      Continue <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        )}

        {step === 3 && currentMood && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl">Your Mood Assessment</CardTitle>
                  <Button variant="outline" size="sm" onClick={handleRestart} className="flex items-center">
                    <RefreshCcw className="h-4 w-4 mr-2" /> New Assessment
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col md:flex-row items-center gap-6">
                  <div
                    className={`w-24 h-24 rounded-full flex items-center justify-center ${getMoodColor(currentMood)} text-white`}
                  >
                    <div className="text-3xl">{getMoodIcon(currentMood)}</div>
                  </div>

                  <div className="flex-grow text-center md:text-left">
                    <h3 className="text-2xl font-bold mb-2 capitalize">{currentMood}</h3>
                    <p className="text-gray-700 dark:text-gray-300">{getMoodDescription(currentMood)}</p>
                  </div>
                </div>

                <div className="pt-4">
                  <h3 className="text-xl font-semibold mb-4">Personalized Recommendations</h3>

                  <Tabs
                    defaultValue="movies"
                    value={recommendationsTab}
                    onValueChange={(value) => setRecommendationsTab(value as "movies" | "songs")}
                  >
                    <TabsList className="grid w-full grid-cols-2 mb-6">
                      <TabsTrigger value="movies" className="flex items-center gap-2">
                        <Film className="h-4 w-4" /> Movies
                      </TabsTrigger>
                      <TabsTrigger value="songs" className="flex items-center gap-2">
                        <Music className="h-4 w-4" /> Songs
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="movies">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {movieRecommendations[currentMood].map((movie, index) => (
                          <motion.div
                            key={movie.title}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.3, delay: index * 0.1 }}
                          >
                            <Card className="h-full overflow-hidden">
                              <div className="aspect-[2/3] relative">
                                <img
                                  src={movie.image || "/placeholder.svg"}
                                  alt={movie.title}
                                  className="w-full h-full object-cover"
                                />
                                <div className="absolute top-2 right-2">
                                  <Badge className="bg-black/70 hover:bg-black/70">{movie.year}</Badge>
                                </div>
                              </div>
                              <CardContent className="p-4">
                                <h4 className="font-semibold text-lg mb-1">{movie.title}</h4>
                                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                                  {movie.creator} • {movie.genre}
                                </p>
                                <p className="text-sm line-clamp-3">{movie.description}</p>
                              </CardContent>
                            </Card>
                          </motion.div>
                        ))}
                      </div>
                    </TabsContent>

                    <TabsContent value="songs">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {songRecommendations[currentMood].map((song, index) => (
                          <motion.div
                            key={song.title}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.3, delay: index * 0.1 }}
                          >
                            <Card className="h-full overflow-hidden">
                              <div className="aspect-square relative">
                                <img
                                  src={song.image || "/placeholder.svg"}
                                  alt={song.title}
                                  className="w-full h-full object-cover"
                                />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
                                  <div>
                                    <h4 className="font-semibold text-lg text-white mb-1">{song.title}</h4>
                                    <p className="text-sm text-gray-200">
                                      {song.creator} • {song.year}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <CardContent className="p-4">
                                <Badge className="mb-2">{song.genre}</Badge>
                                <p className="text-sm line-clamp-3">{song.description}</p>
                              </CardContent>
                            </Card>
                          </motion.div>
                        ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              </CardContent>
              <CardFooter className="flex justify-center">
                <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                  <Heart className="h-4 w-4 mr-2 text-red-500" />
                  Recommendations are personalized based on your current mood
                </p>
              </CardFooter>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  )
}

