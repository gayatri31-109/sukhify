"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star, MapPin, Phone, Mail, Calendar, Filter, Search, ArrowUpDown } from "lucide-react"

// Define psychologist type
interface Psychologist {
  id: string
  name: string
  title: string
  specialties: string[]
  rating: number
  reviews: number
  experience: number
  location: string
  city: string
  state: string
  phone: string
  email: string
  availability: string
  bio: string
  image: string
}

// Sample data for psychologists
const psychologistsData: Psychologist[] = [
  {
    id: "1",
    name: "Dr. Priya Sharma",
    title: "Clinical Psychologist",
    specialties: ["Anxiety", "Depression", "Trauma"],
    rating: 4.9,
    reviews: 124,
    experience: 15,
    location: "Mind Wellness Clinic, Bandra",
    city: "Mumbai",
    state: "Maharashtra",
    phone: "+91 98765 43210",
    email: "dr.priya@example.com",
    availability: "Mon, Wed, Fri",
    bio: "Dr. Sharma is a clinical psychologist with over 15 years of experience in treating anxiety, depression, and trauma. She uses evidence-based approaches including CBT and EMDR.",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "2",
    name: "Dr. Rajiv Mehta",
    title: "Psychiatrist",
    specialties: ["Bipolar Disorder", "Schizophrenia", "Addiction"],
    rating: 4.8,
    reviews: 98,
    experience: 20,
    location: "New Hope Psychiatric Center, Indiranagar",
    city: "Bangalore",
    state: "Karnataka",
    phone: "+91 98765 43211",
    email: "dr.rajiv@example.com",
    availability: "Tue, Thu, Sat",
    bio: "Dr. Mehta is a psychiatrist specializing in serious mental health conditions. He combines medication management with therapeutic approaches for holistic care.",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "3",
    name: "Dr. Ananya Patel",
    title: "Child Psychologist",
    specialties: ["ADHD", "Autism", "Learning Disabilities"],
    rating: 4.7,
    reviews: 87,
    experience: 12,
    location: "Child Development Center, Jubilee Hills",
    city: "Hyderabad",
    state: "Telangana",
    phone: "+91 98765 43212",
    email: "dr.ananya@example.com",
    availability: "Mon-Fri",
    bio: "Dr. Patel specializes in child psychology with a focus on neurodevelopmental disorders. She works closely with families and schools to support children's mental health.",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "4",
    name: "Dr. Vikram Singh",
    title: "Neuropsychologist",
    specialties: ["Brain Injury", "Cognitive Disorders", "Dementia"],
    rating: 4.9,
    reviews: 76,
    experience: 18,
    location: "Neuroscience Center, Vasant Vihar",
    city: "Delhi",
    state: "Delhi",
    phone: "+91 98765 43213",
    email: "dr.vikram@example.com",
    availability: "Mon, Wed, Fri",
    bio: "Dr. Singh specializes in neuropsychological assessment and rehabilitation. He works with patients who have experienced brain injuries or are dealing with cognitive disorders.",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "5",
    name: "Dr. Meera Kapoor",
    title: "Relationship Counselor",
    specialties: ["Couples Therapy", "Family Therapy", "Marital Issues"],
    rating: 4.6,
    reviews: 112,
    experience: 14,
    location: "Family Counseling Center, Alwarpet",
    city: "Chennai",
    state: "Tamil Nadu",
    phone: "+91 98765 43214",
    email: "dr.meera@example.com",
    availability: "Tue, Thu, Sat",
    bio: "Dr. Kapoor is a relationship counselor with expertise in couples and family therapy. She helps clients navigate relationship challenges and improve communication.",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "6",
    name: "Dr. Arjun Nair",
    title: "Addiction Specialist",
    specialties: ["Substance Abuse", "Behavioral Addictions", "Recovery"],
    rating: 4.7,
    reviews: 93,
    experience: 16,
    location: "Recovery Center, Koregaon Park",
    city: "Pune",
    state: "Maharashtra",
    phone: "+91 98765 43215",
    email: "dr.arjun@example.com",
    availability: "Mon-Sat",
    bio: "Dr. Nair specializes in addiction treatment and recovery. He uses a combination of therapeutic approaches and support systems to help clients overcome addictions.",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "7",
    name: "Dr. Sanjana Roy",
    title: "Geriatric Psychologist",
    specialties: ["Elder Care", "Dementia", "Late-life Depression"],
    rating: 4.8,
    reviews: 68,
    experience: 13,
    location: "Senior Wellness Center, Salt Lake",
    city: "Kolkata",
    state: "West Bengal",
    phone: "+91 98765 43216",
    email: "dr.sanjana@example.com",
    availability: "Mon, Wed, Fri",
    bio: "Dr. Roy specializes in geriatric psychology, focusing on mental health issues affecting older adults. She provides compassionate care for seniors and support for their families.",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "8",
    name: "Dr. Karan Malhotra",
    title: "Sports Psychologist",
    specialties: ["Performance Anxiety", "Motivation", "Injury Recovery"],
    rating: 4.9,
    reviews: 82,
    experience: 11,
    location: "Sports Excellence Center, Panchkula",
    city: "Chandigarh",
    state: "Punjab",
    phone: "+91 98765 43217",
    email: "dr.karan@example.com",
    availability: "Tue, Thu, Sat",
    bio: "Dr. Malhotra works with athletes to enhance performance and overcome mental barriers. He helps clients develop mental toughness and resilience in competitive environments.",
    image: "/placeholder.svg?height=200&width=200",
  },
]

export default function Psychologists() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSpecialty, setSelectedSpecialty] = useState("all")
  const [selectedLocation, setSelectedLocation] = useState("all-locations")
  const [sortBy, setSortBy] = useState("rating")
  const [filteredPsychologists, setFilteredPsychologists] = useState<Psychologist[]>(psychologistsData)
  const [selectedPsychologist, setSelectedPsychologist] = useState<Psychologist | null>(null)

  // Get unique specialties for filter
  const allSpecialties = Array.from(new Set(psychologistsData.flatMap((p) => p.specialties))).sort()

  // Get unique locations for filter
  const allLocations = Array.from(new Set(psychologistsData.map((p) => p.city))).sort()

  // Filter and sort psychologists
  useEffect(() => {
    let filtered = [...psychologistsData]

    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(term) ||
          p.title.toLowerCase().includes(term) ||
          p.specialties.some((s) => s.toLowerCase().includes(term)),
      )
    }

    // Apply specialty filter
    if (selectedSpecialty && selectedSpecialty !== "all") {
      filtered = filtered.filter((p) => p.specialties.includes(selectedSpecialty))
    }

    // Apply location filter
    if (selectedLocation && selectedLocation !== "all-locations") {
      filtered = filtered.filter((p) => p.city === selectedLocation)
    }

    // Apply sorting
    if (sortBy === "rating") {
      filtered.sort((a, b) => b.rating - a.rating)
    } else if (sortBy === "experience") {
      filtered.sort((a, b) => b.experience - a.experience)
    } else if (sortBy === "reviews") {
      filtered.sort((a, b) => b.reviews - a.reviews)
    }

    setFilteredPsychologists(filtered)
  }, [searchTerm, selectedSpecialty, selectedLocation, sortBy])

  // Function to view psychologist details
  const viewPsychologistDetails = (psychologist: Psychologist) => {
    setSelectedPsychologist(psychologist)
  }

  // Function to close psychologist details
  const closeDetails = () => {
    setSelectedPsychologist(null)
  }

  // Generate star rating display
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${
            i < Math.floor(rating)
              ? "text-yellow-500 fill-yellow-500"
              : i < rating
                ? "text-yellow-500 fill-yellow-500 opacity-50"
                : "text-gray-300"
          }`}
        />
      ))
  }

  return (
    <div className="container mx-auto px-4 py-32">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
          Find Top Psychologists
        </h1>
        <p className="text-lg text-gray-700 dark:text-gray-300 mb-10 text-center max-w-3xl mx-auto">
          Connect with India's leading mental health professionals. Browse by specialty, location, or ratings to find
          the right support for your needs.
        </p>
      </motion.div>

      <div className="max-w-6xl mx-auto">
        {/* Filters and Search */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search by name or specialty..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
                <SelectTrigger>
                  <SelectValue placeholder="Specialty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specialties</SelectItem>
                  {allSpecialties.map((specialty) => (
                    <SelectItem key={specialty} value={specialty}>
                      {specialty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4 text-gray-500" />
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger>
                  <SelectValue placeholder="Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-locations">All Locations</SelectItem>
                  {allLocations.map((location) => (
                    <SelectItem key={location} value={location}>
                      {location}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <ArrowUpDown className="h-4 w-4 text-gray-500" />
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="experience">Most Experienced</SelectItem>
                  <SelectItem value="reviews">Most Reviews</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Results */}
        {selectedPsychologist ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="mb-8">
              <CardHeader className="pb-4">
                <Button variant="ghost" size="sm" onClick={closeDetails} className="absolute right-4 top-4">
                  Back to List
                </Button>
                <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
                  <Avatar className="h-24 w-24 border-2 border-purple-200">
                    <AvatarImage src={selectedPsychologist.image} alt={selectedPsychologist.name} />
                    <AvatarFallback className="text-2xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
                      {selectedPsychologist.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>

                  <div>
                    <CardTitle className="text-2xl">{selectedPsychologist.name}</CardTitle>
                    <CardDescription className="text-lg">{selectedPsychologist.title}</CardDescription>

                    <div className="flex items-center mt-2">
                      <div className="flex mr-2">{renderStars(selectedPsychologist.rating)}</div>
                      <span className="text-sm">
                        {selectedPsychologist.rating} ({selectedPsychologist.reviews} reviews)
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-2 mt-3">
                      {selectedPsychologist.specialties.map((specialty) => (
                        <Badge key={specialty} variant="secondary">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">About</h3>
                  <p className="text-gray-700 dark:text-gray-300">{selectedPsychologist.bio}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Experience</h3>
                      <p className="text-gray-700 dark:text-gray-300">
                        {selectedPsychologist.experience} years of professional experience
                      </p>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-2">Location</h3>
                      <div className="flex items-start">
                        <MapPin className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
                        <div>
                          <p className="text-gray-700 dark:text-gray-300">{selectedPsychologist.location}</p>
                          <p className="text-gray-700 dark:text-gray-300">
                            {selectedPsychologist.city}, {selectedPsychologist.state}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Availability</h3>
                      <div className="flex items-center">
                        <Calendar className="h-5 w-5 text-gray-500 mr-2" />
                        <p className="text-gray-700 dark:text-gray-300">{selectedPsychologist.availability}</p>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-2">Contact Information</h3>
                      <div className="space-y-2">
                        <div className="flex items-center">
                          <Phone className="h-5 w-5 text-gray-500 mr-2" />
                          <p className="text-gray-700 dark:text-gray-300">{selectedPsychologist.phone}</p>
                        </div>
                        <div className="flex items-center">
                          <Mail className="h-5 w-5 text-gray-500 mr-2" />
                          <p className="text-gray-700 dark:text-gray-300">{selectedPsychologist.email}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>

              <CardFooter className="flex flex-col sm:flex-row gap-4">
                <Button className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700">
                  Schedule Appointment
                </Button>
                <Button variant="outline" className="w-full sm:w-auto">
                  Send Message
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ) : (
          <>
            {filteredPsychologists.length > 0 ? (
              <motion.div
                variants={{
                  hidden: { opacity: 0 },
                  show: {
                    opacity: 1,
                    transition: {
                      staggerChildren: 0.1,
                    },
                  },
                }}
                initial="hidden"
                animate="show"
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              >
                {filteredPsychologists.map((psychologist) => (
                  <motion.div
                    key={psychologist.id}
                    variants={{
                      hidden: { opacity: 0, y: 20 },
                      show: { opacity: 1, y: 0 },
                    }}
                  >
                    <Card className="h-full hover:shadow-lg transition-shadow duration-300">
                      <CardHeader className="pb-4">
                        <div className="flex items-start gap-4">
                          <Avatar>
                            <AvatarImage src={psychologist.image} alt={psychologist.name} />
                            <AvatarFallback className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
                              {psychologist.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <CardTitle className="text-lg">{psychologist.name}</CardTitle>
                            <CardDescription>{psychologist.title}</CardDescription>

                            <div className="flex items-center mt-1">
                              <div className="flex mr-2">{renderStars(psychologist.rating)}</div>
                              <span className="text-xs">({psychologist.reviews})</span>
                            </div>
                          </div>
                        </div>
                      </CardHeader>

                      <CardContent className="pb-4">
                        <div className="flex flex-wrap gap-1 mb-3">
                          {psychologist.specialties.map((specialty) => (
                            <Badge key={specialty} variant="outline" className="text-xs">
                              {specialty}
                            </Badge>
                          ))}
                        </div>

                        <div className="space-y-2 text-sm">
                          <div className="flex items-start">
                            <MapPin className="h-4 w-4 text-gray-500 mr-2 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-700 dark:text-gray-300">
                              {psychologist.city}, {psychologist.state}
                            </span>
                          </div>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 text-gray-500 mr-2 flex-shrink-0" />
                            <span className="text-gray-700 dark:text-gray-300">{psychologist.availability}</span>
                          </div>
                        </div>
                      </CardContent>

                      <CardFooter>
                        <Button
                          onClick={() => viewPsychologistDetails(psychologist)}
                          className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                        >
                          View Profile
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold mb-2">No psychologists found</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">Try adjusting your filters or search terms</p>
                <Button
                  onClick={() => {
                    setSearchTerm("")
                    setSelectedSpecialty("all")
                    setSelectedLocation("all-locations")
                  }}
                  variant="outline"
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

