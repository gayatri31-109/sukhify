"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/contexts/auth-context"
import { LogIn, UserPlus } from "lucide-react"

export default function AuthNav() {
  const { isAuthenticated } = useAuth()

  if (isAuthenticated) {
    return null
  }

  return (
    <div className="flex items-center space-x-2">
      <Button asChild variant="ghost" size="sm">
        <Link href="/login" className="flex items-center">
          <LogIn className="h-4 w-4 mr-2" />
          Login
        </Link>
      </Button>
      <Button
        asChild
        size="sm"
        className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
      >
        <Link href="/register" className="flex items-center">
          <UserPlus className="h-4 w-4 mr-2" />
          Register
        </Link>
      </Button>
    </div>
  )
}

