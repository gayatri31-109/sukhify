"use client"

import Link from "next/link"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, ArrowRight, CheckCircle, Brain } from "lucide-react"
import ProtectedRoute from "@/components/protected-route"

// User types and their specific questions
const userTypes = [
  { id: "student", label: "Student" },
  { id: "parent", label: "Parent" },
  { id: "employee", label: "Employee" },
  { id: "teenager", label: "Teenager" },
  { id: "psychologist", label: "Psychologist" },
]

// Questions for each user type
const questionsByType = {
  student: [
    { id: 1, text: "How often do you feel overwhelmed by academic pressure?" },
    { id: 2, text: "Do you have trouble concentrating on your studies?" },
    { id: 3, text: "How often do you feel anxious about exams or assignments?" },
    { id: 4, text: "Do you have difficulty balancing academics with other activities?" },
    { id: 5, text: "How often do you feel stressed about your future career?" },
    { id: 6, text: "Do you experience physical symptoms (headaches, stomach aches) due to academic stress?" },
    { id: 7, text: "How often do you feel you're not meeting expectations?" },
    { id: 8, text: "Do you have trouble sleeping due to academic worries?" },
    { id: 9, text: "How often do you feel competitive pressure from peers?" },
    { id: 10, text: "Do you feel you have adequate support for your academic challenges?" },
  ],
  parent: [
    { id: 1, text: "How often do you feel overwhelmed by parenting responsibilities?" },
    { id: 2, text: "Do you struggle to balance work and family life?" },
    { id: 3, text: "How often do you feel you're not meeting your children's needs?" },
    { id: 4, text: "Do you have difficulty finding time for self-care?" },
    { id: 5, text: "How often do you feel judged by others about your parenting?" },
    { id: 6, text: "Do you worry excessively about your children's future?" },
    { id: 7, text: "How often do you feel financially stressed about family needs?" },
    { id: 8, text: "Do you have adequate support in your parenting journey?" },
    { id: 9, text: "How often do you feel exhausted by the end of the day?" },
    { id: 10, text: "Do you experience guilt when taking time for yourself?" },
  ],
  employee: [
    { id: 1, text: "How often do you feel overwhelmed by your workload?" },
    { id: 2, text: "Do you experience stress from meeting deadlines?" },
    { id: 3, text: "How often do you feel anxious about job security?" },
    { id: 4, text: "Do you have difficulty maintaining work-life balance?" },
    { id: 5, text: "How often do you feel undervalued at work?" },
    { id: 6, text: "Do you experience physical symptoms due to work stress?" },
    { id: 7, text: "How often do you feel burnout from your job?" },
    { id: 8, text: "Do you have conflicts with colleagues or management?" },
    { id: 9, text: "How often do you bring work stress home?" },
    { id: 10, text: "Do you have adequate support for workplace challenges?" },
  ],
  teenager: [
    { id: 1, text: "How often do you feel pressure from school or academics?" },
    { id: 2, text: "Do you experience stress from social relationships?" },
    { id: 3, text: "How often do you feel anxious about your appearance?" },
    { id: 4, text: "Do you have difficulty communicating with your parents?" },
    { id: 5, text: "How often do you feel misunderstood by adults?" },
    { id: 6, text: "Do you worry about your future?" },
    { id: 7, text: "How often do you feel overwhelmed by social media?" },
    { id: 8, text: "Do you experience peer pressure that causes stress?" },
    { id: 9, text: "How often do you feel you can't meet expectations?" },
    { id: 10, text: "Do you have someone you can talk to about your problems?" },
  ],
  psychologist: [
    { id: 1, text: "How often do you experience compassion fatigue?" },
    { id: 2, text: "Do you find it difficult to maintain boundaries with clients?" },
    { id: 3, text: "How often do you feel emotionally drained after sessions?" },
    { id: 4, text: "Do you have adequate supervision and support?" },
    { id: 5, text: "How often do you practice self-care?" },
    { id: 6, text: "Do you worry about your clients outside of sessions?" },
    { id: 7, text: "How often do you feel overwhelmed by your caseload?" },
    { id: 8, text: "Do you experience burnout symptoms?" },
    { id: 9, text: "How often do you feel isolated in your practice?" },
    { id: 10, text: "Do you have difficulty balancing professional and personal life?" },
  ],
}

// Answer options
const answerOptions = [
  { value: 1, label: "Never" },
  { value: 2, label: "Rarely" },
  { value: 3, label: "Sometimes" },
  { value: 4, label: "Often" },
  { value: 5, label: "Always" },
]

// Stress level categories
const stressLevels = [
  {
    range: [10, 20],
    level: "Low",
    color: "bg-green-500",
    description:
      "Your stress levels appear to be well-managed. Continue with your current coping strategies and self-care practices.",
  },
  {
    range: [21, 30],
    level: "Mild",
    color: "bg-blue-500",
    description:
      "You're experiencing mild stress. Consider incorporating more relaxation techniques into your routine.",
  },
  {
    range: [31, 40],
    level: "Moderate",
    color: "bg-yellow-500",
    description:
      "You're experiencing moderate stress. It's important to address these stress levels with regular self-care and stress management techniques.",
  },
  {
    range: [41, 50],
    level: "High",
    color: "bg-orange-500",
    description:
      "Your stress levels are high. Consider speaking with a mental health professional and prioritizing stress reduction strategies.",
  },
]

// Recommendations based on stress levels
const recommendations = {
  Low: [
    "Continue your current self-care practices",
    "Practice mindfulness for 5-10 minutes daily",
    "Maintain regular physical activity",
    "Ensure adequate sleep (7-8 hours)",
    "Stay connected with your support network",
  ],
  Mild: [
    "Incorporate deep breathing exercises twice daily",
    "Practice progressive muscle relaxation before bed",
    "Take short breaks throughout the day",
    "Limit caffeine and alcohol consumption",
    "Consider starting a stress journal to identify triggers",
  ],
  Moderate: [
    "Schedule regular relaxation time in your calendar",
    "Try guided meditation for stress reduction",
    "Establish clear boundaries in work and personal life",
    "Practice the 4-7-8 breathing technique when feeling overwhelmed",
    "Consider joining a support group or community",
  ],
  High: [
    "Consult with a mental health professional",
    "Practice daily stress reduction techniques",
    "Evaluate and adjust work/life commitments if possible",
    "Prioritize self-care activities",
    "Consider learning cognitive behavioral techniques for stress management",
  ],
}

export default function StressEvaluation() {
  const [step, setStep] = useState(1)
  const [userType, setUserType] = useState("")
  const [answers, setAnswers] = useState<Record<number, number>>({})
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [result, setResult] = useState<{
    score: number
    level: string
    color: string
    description: string
    recommendations: string[]
  } | null>(null)

  const questions = userType ? questionsByType[userType as keyof typeof questionsByType] : []
  const currentQuestion = questions[currentQuestionIndex]
  const progress = userType ? ((currentQuestionIndex + 1) / questions.length) * 100 : 0

  const handleUserTypeSelect = (value: string) => {
    setUserType(value)
    setAnswers({})
    setCurrentQuestionIndex(0)
  }

  const handleAnswerSelect = (questionId: number, value: number) => {
    setAnswers({ ...answers, [questionId]: value })
  }

  const handleNext = () => {
    if (step === 1 && userType) {
      setStep(2)
    } else if (step === 2) {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1)
      } else {
        // Calculate result
        const totalScore = Object.values(answers).reduce((sum, value) => sum + value, 0)

        // Determine stress level
        const stressLevel = stressLevels.find((level) => totalScore >= level.range[0] && totalScore <= level.range[1])

        if (stressLevel) {
          setResult({
            score: totalScore,
            level: stressLevel.level,
            color: stressLevel.color,
            description: stressLevel.description,
            recommendations: recommendations[stressLevel.level as keyof typeof recommendations],
          })
          setStep(3)
        }
      }
    }
  }

  const handlePrevious = () => {
    if (step === 2) {
      if (currentQuestionIndex > 0) {
        setCurrentQuestionIndex(currentQuestionIndex - 1)
      } else {
        setStep(1)
      }
    } else if (step === 3) {
      setStep(2)
      setCurrentQuestionIndex(questions.length - 1)
    }
  }

  const handleRestart = () => {
    setStep(1)
    setUserType("")
    setAnswers({})
    setCurrentQuestionIndex(0)
    setResult(null)
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-32">
        <div className="max-w-3xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
              Stress Evaluation
            </h1>
            <p className="text-lg text-gray-700 dark:text-gray-300 mb-10 text-center">
              Answer a few questions to help us understand your stress levels and provide personalized recommendations.
            </p>
          </motion.div>

          {step === 1 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Select Your Profile</CardTitle>
                  <CardDescription>
                    Choose the option that best describes you to receive tailored questions.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Select value={userType} onValueChange={handleUserTypeSelect}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select your profile" />
                    </SelectTrigger>
                    <SelectContent>
                      {userTypes.map((type) => (
                        <SelectItem key={type.id} value={type.id}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button
                    onClick={handleNext}
                    disabled={!userType}
                    className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                  >
                    Continue <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          )}

          {step === 2 && currentQuestion && (
            <motion.div
              key={currentQuestion.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center mb-2">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">
                      Question {currentQuestionIndex + 1} of {questions.length}
                    </div>
                    <div className="text-sm font-medium text-purple-600 dark:text-purple-400">
                      {userTypes.find((type) => type.id === userType)?.label}
                    </div>
                  </div>
                  <Progress value={progress} className="h-2 mb-4" />
                  <CardTitle className="text-xl">{currentQuestion.text}</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={answers[currentQuestion.id]?.toString()}
                    onValueChange={(value) => handleAnswerSelect(currentQuestion.id, Number.parseInt(value))}
                    className="space-y-3"
                  >
                    {answerOptions.map((option) => (
                      <div key={option.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={option.value.toString()} id={`option-${option.value}`} />
                        <Label htmlFor={`option-${option.value}`} className="flex-grow cursor-pointer">
                          {option.label}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={handlePrevious}>
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back
                  </Button>
                  <Button
                    onClick={handleNext}
                    disabled={!answers[currentQuestion.id]}
                    className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                  >
                    {currentQuestionIndex < questions.length - 1 ? (
                      <>
                        Next <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    ) : (
                      <>
                        Complete <CheckCircle className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          )}

          {step === 3 && result && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">Your Stress Evaluation Results</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex flex-col items-center">
                    <div className={`w-32 h-32 rounded-full ${result.color} flex items-center justify-center mb-4`}>
                      <span className="text-white text-3xl font-bold">{result.score}</span>
                    </div>
                    <h3 className="text-2xl font-bold mb-2">{result.level} Stress Level</h3>
                    <p className="text-center text-gray-700 dark:text-gray-300 mb-6">{result.description}</p>
                  </div>

                  <div>
                    <h4 className="text-xl font-semibold mb-4 flex items-center">
                      <Brain className="mr-2 h-5 w-5 text-purple-600" />
                      Recommendations
                    </h4>
                    <ul className="space-y-2">
                      {result.recommendations.map((recommendation, index) => (
                        <motion.li
                          key={index}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                          className="flex items-start"
                        >
                          <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                          <span>{recommendation}</span>
                        </motion.li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button variant="outline" onClick={handleRestart}>
                    Take Assessment Again
                  </Button>
                  <Button
                    asChild
                    className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                  >
                    <Link href="/relaxation">Explore Relaxation Techniques</Link>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </ProtectedRoute>
  )
}

