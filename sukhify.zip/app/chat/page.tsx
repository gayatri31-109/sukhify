"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Send, Bot, User, Sparkles, RefreshCcw, ThumbsUp, ThumbsDown, Copy, Info } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

// Define message type
interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

// Define suggested questions
const suggestedQuestions = [
  "How can I manage exam anxiety?",
  "What are some quick stress relief techniques?",
  "How can I improve my sleep quality?",
  "What should I do when I feel overwhelmed?",
  "How can I set healthy boundaries?",
  "What are signs of burnout I should watch for?",
]

export default function ChatSupport() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Hello! I'm Sukhify's mental health assistant. I'm here to provide support and information about mental health. How can I help you today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [activeTab, setActiveTab] = useState("chat")

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Function to generate a unique ID
  const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2)
  }

  // Function to handle sending a message
  const handleSendMessage = async (messageText: string = input) => {
    if (!messageText.trim()) return

    // Add user message to chat
    const userMessage: Message = {
      id: generateId(),
      role: "user",
      content: messageText,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      // In a real implementation, this would call the Gemini API
      // For now, we'll simulate a response
      setTimeout(() => {
        const assistantMessage: Message = {
          id: generateId(),
          role: "assistant",
          content: generateResponse(messageText),
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, assistantMessage])
        setIsLoading(false)
      }, 1500)
    } catch (error) {
      console.error("Error sending message:", error)
      setIsLoading(false)
    }
  }

  // Function to simulate AI response (in a real app, this would call the Gemini API)
  const generateResponse = (message: string): string => {
    const lowerMessage = message.toLowerCase()

    if (lowerMessage.includes("anxiety") || lowerMessage.includes("anxious")) {
      return "Anxiety is a common experience. Some helpful techniques include deep breathing, progressive muscle relaxation, and mindfulness meditation. If your anxiety is persistent or interfering with daily life, consider speaking with a mental health professional. Would you like me to explain any of these techniques in more detail?"
    } else if (lowerMessage.includes("stress") || lowerMessage.includes("stressed")) {
      return "Stress management is important for mental wellbeing. Consider trying the 4-7-8 breathing technique, regular physical activity, or setting boundaries. Our relaxation techniques page has guided exercises you might find helpful. What specific aspect of stress are you dealing with?"
    } else if (lowerMessage.includes("sleep") || lowerMessage.includes("insomnia")) {
      return "Good sleep is crucial for mental health. Try establishing a regular sleep schedule, creating a relaxing bedtime routine, and limiting screen time before bed. If sleep problems persist, consider consulting with a healthcare provider. Would you like more specific sleep hygiene tips?"
    } else if (lowerMessage.includes("depression") || lowerMessage.includes("sad")) {
      return "I'm sorry to hear you're feeling this way. While temporary feelings of sadness are normal, persistent feelings of hopelessness or sadness might indicate depression. Regular exercise, social connection, and professional support can help. Would you like information about connecting with a mental health professional?"
    } else if (lowerMessage.includes("meditation") || lowerMessage.includes("mindfulness")) {
      return "Mindfulness meditation can be a powerful tool for mental wellbeing. Start with just 5 minutes daily of focusing on your breath. When your mind wanders, gently bring attention back to your breathing. Our relaxation techniques page has guided meditations you might find helpful. Would you like more specific meditation instructions?"
    } else {
      return "Thank you for sharing. Mental health is a journey, and it's important to be kind to yourself along the way. Would you like to explore specific coping strategies, relaxation techniques, or information about professional support? I'm here to help with whatever you need."
    }
  }

  // Function to handle pressing Enter to send message
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  // Function to clear chat history
  const handleClearChat = () => {
    setMessages([
      {
        id: "welcome",
        role: "assistant",
        content:
          "Hello! I'm Sukhify's mental health assistant. I'm here to provide support and information about mental health. How can I help you today?",
        timestamp: new Date(),
      },
    ])
  }

  // Function to copy message to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    // In a real app, you would show a toast notification here
  }

  return (
    <div className="container mx-auto px-4 py-32">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-4xl mx-auto"
      >
        <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
          Chat Support
        </h1>
        <p className="text-lg text-gray-700 dark:text-gray-300 mb-10 text-center">
          Chat with our AI assistant for mental health support and guidance.
        </p>

        <Tabs defaultValue="chat" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <Bot className="h-4 w-4" /> Chat Assistant
            </TabsTrigger>
            <TabsTrigger value="info" className="flex items-center gap-2">
              <Info className="h-4 w-4" /> About This Service
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat">
            <Card className="border-none shadow-lg">
              <CardHeader className="pb-4">
                <div className="flex items-center space-x-4">
                  <Avatar>
                    <AvatarImage src="/placeholder.svg?height=40&width=40" alt="AI Assistant" />
                    <AvatarFallback className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
                      AI
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle>Sukhify Assistant</CardTitle>
                    <CardDescription>Powered by Gemini AI</CardDescription>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="absolute right-4 top-4" onClick={handleClearChat}>
                  <RefreshCcw className="h-4 w-4 mr-2" /> New Chat
                </Button>
              </CardHeader>

              <CardContent>
                <div className="h-[400px] overflow-y-auto mb-4 space-y-4 p-1">
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div className={`flex gap-3 max-w-[80%] ${message.role === "user" ? "flex-row-reverse" : ""}`}>
                        <Avatar className="h-8 w-8">
                          {message.role === "assistant" ? (
                            <>
                              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="AI" />
                              <AvatarFallback className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs">
                                AI
                              </AvatarFallback>
                            </>
                          ) : (
                            <>
                              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
                              <AvatarFallback className="bg-gray-200 dark:bg-gray-700 text-xs">
                                <User className="h-4 w-4" />
                              </AvatarFallback>
                            </>
                          )}
                        </Avatar>

                        <div className="space-y-1">
                          <div
                            className={`p-3 rounded-lg relative group ${
                              message.role === "assistant"
                                ? "bg-gray-100 dark:bg-gray-800"
                                : "bg-gradient-to-r from-purple-600 to-indigo-600 text-white"
                            }`}
                          >
                            <p className="text-sm whitespace-pre-wrap">{message.content}</p>

                            {message.role === "assistant" && (
                              <div className="absolute -right-10 top-2 hidden group-hover:flex items-center space-x-1">
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-7 w-7"
                                        onClick={() => copyToClipboard(message.content)}
                                      >
                                        <Copy className="h-3.5 w-3.5" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>Copy to clipboard</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>

                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button variant="ghost" size="icon" className="h-7 w-7">
                                        <ThumbsUp className="h-3.5 w-3.5" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>Helpful</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>

                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button variant="ghost" size="icon" className="h-7 w-7">
                                        <ThumbsDown className="h-3.5 w-3.5" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>Not helpful</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              </div>
                            )}
                          </div>

                          <div className={`text-xs text-gray-500 ${message.role === "user" ? "text-right" : ""}`}>
                            {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}

                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                        <div className="flex space-x-2">
                          <div
                            className="w-2 h-2 rounded-full bg-purple-600 animate-bounce"
                            style={{ animationDelay: "0ms" }}
                          ></div>
                          <div
                            className="w-2 h-2 rounded-full bg-purple-600 animate-bounce"
                            style={{ animationDelay: "150ms" }}
                          ></div>
                          <div
                            className="w-2 h-2 rounded-full bg-purple-600 animate-bounce"
                            style={{ animationDelay: "300ms" }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  )}

                  <div ref={messagesEndRef} />
                </div>

                {messages.length === 1 && (
                  <div className="mb-4">
                    <h3 className="text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Suggested questions:</h3>
                    <div className="flex flex-wrap gap-2">
                      {suggestedQuestions.map((question, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => handleSendMessage(question)}
                        >
                          {question}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>

              <CardFooter>
                <div className="relative w-full">
                  <Textarea
                    placeholder="Type your message here..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    className="pr-12 min-h-[60px] max-h-[200px] resize-none"
                    disabled={isLoading}
                  />
                  <Button
                    size="icon"
                    className="absolute right-2 bottom-2 h-8 w-8 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                    onClick={() => handleSendMessage()}
                    disabled={!input.trim() || isLoading}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="info">
            <Card>
              <CardHeader>
                <CardTitle>About Sukhify Chat Support</CardTitle>
                <CardDescription>Understanding how our AI assistant works and its limitations</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold flex items-center">
                    <Sparkles className="h-5 w-5 mr-2 text-purple-600" /> How It Works
                  </h3>
                  <p>
                    Sukhify's chat assistant is powered by Google's Gemini AI technology. It's designed to provide
                    information, resources, and support for mental health concerns. The assistant can help with:
                  </p>
                  <ul className="list-disc list-inside ml-4 space-y-1">
                    <li>Providing information about mental health topics</li>
                    <li>Suggesting coping strategies and relaxation techniques</li>
                    <li>Offering guidance on when to seek professional help</li>
                    <li>Directing you to appropriate resources</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-semibold">Important Limitations</h3>
                  <div className="bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-900 rounded-lg p-4">
                    <p className="text-amber-800 dark:text-amber-300 font-medium mb-2">
                      This AI assistant is not a replacement for professional mental health care.
                    </p>
                    <ul className="list-disc list-inside ml-4 space-y-1 text-amber-700 dark:text-amber-400">
                      <li>It cannot diagnose medical conditions</li>
                      <li>It cannot provide personalized medical advice</li>
                      <li>It cannot replace therapy or counseling</li>
                      <li>It may not always understand the full context of your situation</li>
                    </ul>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-semibold">Privacy Information</h3>
                  <p>
                    Your conversations with the AI assistant are processed according to our privacy policy. While we
                    strive to maintain confidentiality, please do not share sensitive personal information that you
                    wouldn't want stored or processed.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-semibold">In Case of Emergency</h3>
                  <div className="bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 rounded-lg p-4">
                    <p className="text-red-800 dark:text-red-300 font-medium">
                      If you're experiencing a mental health emergency or having thoughts of harming yourself or others,
                      please contact emergency services immediately:
                    </p>
                    <ul className="list-disc list-inside ml-4 space-y-1 text-red-700 dark:text-red-400 mt-2">
                      <li>Emergency Services: 112 or 108</li>
                      <li>National Mental Health Helpline: 1800-599-0019</li>
                      <li>
                        Visit our{" "}
                        <a href="/emergency" className="underline">
                          Emergency Support
                        </a>{" "}
                        page for more resources
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  onClick={() => setActiveTab("chat")}
                  className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                >
                  Start Chatting
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  )
}

