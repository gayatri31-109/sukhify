import bcryptjs from "bcryptjs"

// In a real application, these would be stored in a database
// This is just for demonstration purposes
const USERS = [
  {
    id: "1",
    username: "admin",
    // This is a hashed version of "sukhify123"
    passwordHash: "$2a$10$XQtA0mVGKPZGxOvQvEBx8OcFJX1VnaBvMgqX6WW9Wy.ODXVvyQ0Uu",
    email: "admin@sukhify.com",
    role: "admin",
    twoFactorSecret: "JBSWY3DPEHPK3PXP", // Example TOTP secret
    createdAt: new Date().toISOString(),
  },
]

// Secret key for JWT signing - in a real app, this would be an environment variable
const JWT_SECRET = "sukhify-jwt-secret-key-2024-demo-only"

// Token expiration time
const TOKEN_EXPIRY = "2h"

// Maximum login attempts before temporary lockout
const MAX_LOGIN_ATTEMPTS = 5

// Store login attempts in memory (in a real app, this would be in a database or Redis)
const loginAttempts: Record<string, { count: number; lastAttempt: number }> = {}

// Check if user is locked out due to too many failed attempts
export function isUserLockedOut(username: string): boolean {
  const attempts = loginAttempts[username]
  if (!attempts) return false

  // Lock out for 15 minutes (900000 ms) after max attempts
  const lockoutDuration = 15 * 60 * 1000
  const isLocked = attempts.count >= MAX_LOGIN_ATTEMPTS && Date.now() - attempts.lastAttempt < lockoutDuration

  // Reset attempts after lockout period
  if (attempts.count >= MAX_LOGIN_ATTEMPTS && !isLocked) {
    loginAttempts[username] = { count: 0, lastAttempt: Date.now() }
  }

  return isLocked
}

// Record a failed login attempt
export function recordFailedAttempt(username: string): void {
  const attempts = loginAttempts[username] || { count: 0, lastAttempt: 0 }
  loginAttempts[username] = {
    count: attempts.count + 1,
    lastAttempt: Date.now(),
  }
}

// Reset login attempts after successful login
export function resetLoginAttempts(username: string): void {
  loginAttempts[username] = { count: 0, lastAttempt: 0 }
}

// Hash a password
export async function hashPassword(password: string): Promise<string> {
  return bcryptjs.hash(password, 10)
}

// Verify password against hash
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcryptjs.compare(password, hash)
}

// Find user by username
export function findUserByUsername(username: string) {
  return USERS.find((user) => user.username.toLowerCase() === username.toLowerCase())
}

// Find user by email
export function findUserByEmail(email: string) {
  return USERS.find((user) => user.email.toLowerCase() === email.toLowerCase())
}

// Register a new user
export async function registerUser(
  username: string,
  email: string,
  password: string,
): Promise<{ success: boolean; message?: string; user?: any }> {
  // Check if username already exists
  if (findUserByUsername(username)) {
    return { success: false, message: "Username already taken" }
  }

  // Check if email already exists
  if (findUserByEmail(email)) {
    return { success: false, message: "Email already registered" }
  }

  // Hash the password
  const passwordHash = await hashPassword(password)

  // Create a new user
  const newUser = {
    id: (USERS.length + 1).toString(),
    username,
    email,
    passwordHash,
    role: "user", // Default role for new users
    twoFactorSecret: "JBSWY3DPEHPK3PXP", // In a real app, this would be generated uniquely
    createdAt: new Date().toISOString(),
  }

  // Add the user to our "database"
  USERS.push(newUser)

  // Return the user without sensitive information
  return {
    success: true,
    user: {
      id: newUser.id,
      username: newUser.username,
      email: newUser.email,
      role: newUser.role,
      createdAt: newUser.createdAt,
    },
  }
}

// Generate JWT token
export function generateToken(userId: string, username: string, role: string): string {
  // In a real app, you would use a proper JWT library
  // This is a simplified version for demonstration
  const payload = {
    sub: userId,
    username,
    role,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 2 * 60 * 60, // 2 hours
  }

  // Encode the payload to base64
  const encodedPayload = Buffer.from(JSON.stringify(payload)).toString("base64")

  // In a real app, you would sign this with a proper algorithm
  // This is a simplified version
  const signature = Buffer.from(JWT_SECRET + encodedPayload).toString("base64")

  return `${encodedPayload}.${signature}`
}

// Verify JWT token
export function verifyToken(token: string): { valid: boolean; payload?: any } {
  try {
    // In a real app, you would use a proper JWT verification
    // This is a simplified version
    const [encodedPayload, signature] = token.split(".")

    const expectedSignature = Buffer.from(JWT_SECRET + encodedPayload).toString("base64")

    if (signature !== expectedSignature) {
      return { valid: false }
    }

    const payload = JSON.parse(Buffer.from(encodedPayload, "base64").toString())

    // Check if token is expired
    if (payload.exp < Math.floor(Date.now() / 1000)) {
      return { valid: false }
    }

    return { valid: true, payload }
  } catch (error) {
    return { valid: false }
  }
}

// Generate a 6-digit verification code (simulating 2FA)
export function generateVerificationCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

// In a real app, this would send the code via SMS or email
export function sendVerificationCode(email: string, code: string): Promise<boolean> {
  console.log(`Sending verification code ${code} to ${email}`)
  // Simulate sending the code
  return Promise.resolve(true)
}

// Verify the 2FA code
// In a real app, this would verify against a TOTP algorithm
export function verifyTwoFactorCode(userCode: string, expectedCode: string): boolean {
  return userCode === expectedCode
}

// Get all users (for admin purposes)
export function getAllUsers() {
  // Return users without sensitive information
  return USERS.map((user) => ({
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    createdAt: user.createdAt,
  }))
}

